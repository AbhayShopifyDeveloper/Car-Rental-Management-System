export type CarCategory = 'All' | 'SUV' | 'Sedan' | 'Luxury' | 'Electric' | 'Sports' | 'Compact' | 'Van';
export type FuelType = 'All' | 'Petrol' | 'Diesel' | 'Hybrid' | 'Electric';
export type TransmissionType = 'All' | 'Automatic' | 'Manual';
export type AvailabilityStatus = 'Available' | 'Reserved' | 'Maintenance';

export interface Car {
  id: string;
  name: string;
  brand: string;
  model: string;
  year: number;
  category: Exclude<CarCategory, 'All'>;
  pricePerDay: number;
  fuelType: Exclude<FuelType, 'All'>;
  transmission: Exclude<TransmissionType, 'All'>;
  seats: number;
  doors: number;
  luggage: number; // luggage capacity bags
  mileage: string; // e.g. "32 MPG" or "310 mi range"
  power: string; // e.g. "300 HP"
  zeroToSixty: string; // e.g. "4.2s"
  rating: number;
  reviewsCount: number;
  isAvailable: boolean;
  status: AvailabilityStatus;
  featured: boolean;
  image: string;
  gallery: string[];
  description: string;
  features: string[];
  location: string;
  dailyIncludedMiles: number;
  depositAmount: number;
}

export interface AddOnOption {
  id: string;
  name: string;
  description: string;
  pricePerDay: number;
  icon: string;
  recommended?: boolean;
}

export interface BookingAddOns {
  insurance: boolean;
  gps: boolean;
  childSeat: boolean;
  additionalDriver: boolean;
  roadside: boolean;
}

export type BookingStatus = 'Confirmed' | 'Active' | 'Completed' | 'Cancelled';

export interface Booking {
  id: string;
  bookingNumber: string;
  carId: string;
  carName: string;
  carBrand: string;
  carImage: string;
  carPricePerDay: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  licenseNumber: string;
  pickupLocation: string;
  dropoffLocation: string;
  pickupDate: string;
  pickupTime: string;
  dropoffDate: string;
  dropoffTime: string;
  totalDays: number;
  addOns: BookingAddOns;
  addOnsCost: number;
  subtotal: number;
  discountCode?: string;
  discountAmount: number;
  taxAmount: number;
  totalPrice: number;
  status: BookingStatus;
  specialRequests?: string;
  createdAt: string;
}

export interface FilterState {
  search: string;
  category: CarCategory;
  fuelType: FuelType;
  transmission: TransmissionType;
  minPrice: number;
  maxPrice: number;
  seats: number | 'All';
  onlyAvailable: boolean;
  sortBy: 'featured' | 'price-asc' | 'price-desc' | 'rating-desc' | 'name-asc';
}

export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'CAD' | 'AUD' | 'INR';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  rate: number; // relative to USD
}

export interface LocationOption {
  id: string;
  name: string;
  address: string;
  type: 'Airport' | 'Downtown' | 'Station' | 'Hotel';
}

export interface Review {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  comment: string;
  carModel: string;
  verified: boolean;
}
