import React from 'react';
import { RentalProvider, useRental } from './context/RentalContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FeaturedCars } from './components/FeaturedCars';
import { CarListing } from './components/CarListing';
import { HowItWorks } from './components/HowItWorks';
import { WhyChooseUs } from './components/WhyChooseUs';
import { Testimonials } from './components/Testimonials';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { CarDetailsModal } from './components/CarDetailsModal';
import { BookingModal } from './components/BookingModal';
import { ReceiptModal } from './components/ReceiptModal';
import { ToastContainer } from './components/ToastContainer';
import { MyBookings } from './components/MyBookings';
import { FleetManagement } from './components/FleetManagement';
import { motion, AnimatePresence } from 'motion/react';

const MainContent: React.FC = () => {
  const { activeTab } = useRental();

  return (
    <div className="min-h-screen bg-[#0a0f1d] text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-slate-950 relative overflow-hidden">
      {/* Background ambient lighting orbs for frosted glass refraction */}
      <div className="fixed top-[-10%] left-[-10%] w-[650px] h-[650px] rounded-full bg-blue-600/15 blur-[150px] pointer-events-none z-0" />
      <div className="fixed top-[30%] right-[-10%] w-[600px] h-[600px] rounded-full bg-amber-500/10 blur-[160px] pointer-events-none z-0" />
      <div className="fixed bottom-[-10%] left-[20%] w-[700px] h-[700px] rounded-full bg-indigo-600/15 blur-[160px] pointer-events-none z-0" />
      <div className="fixed top-[60%] left-[-5%] w-[450px] h-[450px] rounded-full bg-emerald-500/8 blur-[140px] pointer-events-none z-0" />

      <div className="relative z-10 flex flex-col min-h-screen justify-between">
        <Navbar />

        <main className="flex-1">
          <AnimatePresence mode="wait">
            {activeTab === 'home' && (
              <motion.div
                key="home"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
              >
                <Hero />
                <FeaturedCars />
                <CarListing />
                <HowItWorks />
                <WhyChooseUs />
                <Testimonials />
                <FaqSection />
              </motion.div>
            )}

            {activeTab === 'fleet' && (
              <motion.div
                key="fleet"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
                className="pt-6"
              >
                <CarListing />
                <WhyChooseUs />
              </motion.div>
            )}

            {activeTab === 'bookings' && (
              <motion.div
                key="bookings"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
                className="pt-6"
              >
                <MyBookings />
              </motion.div>
            )}

            {activeTab === 'admin' && (
              <motion.div
                key="admin"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
                className="pt-6"
              >
                <FleetManagement />
              </motion.div>
            )}

            {activeTab === 'about' && (
              <motion.div
                key="about"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
                className="pt-6"
              >
                <HowItWorks />
                <WhyChooseUs />
                <Testimonials />
                <FaqSection />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <Footer />
      </div>

      {/* Global Context Modals */}
      <CarDetailsModal />
      <BookingModal />
      <ReceiptModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <RentalProvider>
      <MainContent />
    </RentalProvider>
  );
}
