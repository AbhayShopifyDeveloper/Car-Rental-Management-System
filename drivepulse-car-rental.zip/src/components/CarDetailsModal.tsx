import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { 
  X, 
  Users, 
  Fuel, 
  Zap, 
  Gauge, 
  Luggage, 
  DoorOpen, 
  MapPin, 
  Star, 
  ShieldCheck, 
  Check, 
  Sparkles, 
  ArrowRight,
  Heart,
  CalendarCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const CarDetailsModal: React.FC = () => {
  const { 
    selectedCarForDetails, 
    setSelectedCarForDetails, 
    setSelectedCarForBooking, 
    formatPrice,
    isFavorite,
    toggleFavorite
  } = useRental();

  const [activeImageIndex, setActiveImageIndex] = useState(0);

  if (!selectedCarForDetails) return null;

  const car = selectedCarForDetails;
  const gallery = car.gallery && car.gallery.length > 0 ? car.gallery : [car.image];
  const favorite = isFavorite(car.id);

  const handleBookNow = () => {
    setSelectedCarForDetails(null);
    setSelectedCarForBooking(car);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSelectedCarForDetails(null)}
          className="fixed inset-0 bg-slate-950/85 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-4xl bg-slate-900/60 backdrop-blur-2xl border border-white/15 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.6)] overflow-hidden z-10 my-auto max-h-[92vh] flex flex-col"
        >
          {/* Subtle top sheen */}
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />

          {/* Top Bar with Close & Favorite */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/60 backdrop-blur-xl sticky top-0 z-20">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30 backdrop-blur-md">
                {car.category}
              </span>
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {car.location}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleFavorite(car.id)}
                className="p-2 rounded-full bg-white/[0.05] hover:bg-white/10 text-slate-300 hover:text-rose-400 transition-colors border border-white/10 cursor-pointer"
                aria-label="Toggle favorite"
              >
                <Heart className={`w-5 h-5 ${favorite ? 'fill-rose-500 text-rose-500' : ''}`} />
              </button>
              <button
                onClick={() => setSelectedCarForDetails(null)}
                className="p-2 rounded-full bg-white/[0.05] hover:bg-white/10 text-slate-300 hover:text-white transition-colors border border-white/10 cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Scrollable Content */}
          <div className="overflow-y-auto p-6 space-y-6">
            {/* Main Image & Thumbnails */}
            <div className="space-y-3">
              <div className="relative h-64 sm:h-96 rounded-2xl overflow-hidden bg-black/40 border border-white/10">
                <img
                  src={gallery[activeImageIndex] || car.image}
                  alt={car.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-slate-950/70 backdrop-blur-xl px-3 py-1.5 rounded-xl border border-white/15 flex items-center gap-1.5 text-xs text-amber-300 font-bold shadow-lg">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span>{car.rating.toFixed(1)} / 5.0</span>
                  <span className="text-slate-400 font-normal">({car.reviewsCount} verified reviews)</span>
                </div>
              </div>

              {gallery.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-1">
                  {gallery.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`relative w-20 h-14 rounded-xl overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                        activeImageIndex === idx
                          ? 'border-amber-400 scale-105 shadow-md shadow-amber-500/20'
                          : 'border-white/10 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="thumbnail" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Title & Price Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div>
                <div className="text-xs font-semibold text-slate-400 mb-1">{car.brand} • {car.year} Release</div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{car.name}</h2>
              </div>

              <div className="text-left sm:text-right">
                <div className="text-xs text-slate-400">Daily Rental Fee</div>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-amber-400">{formatPrice(car.pricePerDay)}</span>
                  <span className="text-sm text-slate-400">/day</span>
                </div>
              </div>
            </div>

            {/* Description */}
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-2">Overview</h3>
              <p className="text-sm text-slate-300 leading-relaxed">{car.description}</p>
            </div>

            {/* Full Technical Specifications */}
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3">Vehicle Specifications</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                    <Users className="w-4 h-4 text-amber-400" />
                    <span>Seating Capacity</span>
                  </div>
                  <div className="text-sm font-bold text-white">{car.seats} Passengers</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                    <Luggage className="w-4 h-4 text-amber-400" />
                    <span>Luggage Space</span>
                  </div>
                  <div className="text-sm font-bold text-white">{car.luggage} Large Bags</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                    {car.fuelType === 'Electric' ? (
                      <Zap className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Fuel className="w-4 h-4 text-amber-400" />
                    )}
                    <span>Fuel / Power</span>
                  </div>
                  <div className="text-sm font-bold text-white">{car.fuelType}</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                    <Gauge className="w-4 h-4 text-blue-400" />
                    <span>Transmission</span>
                  </div>
                  <div className="text-sm font-bold text-white">{car.transmission}</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="text-xs text-slate-400 mb-1">Engine Output</div>
                  <div className="text-sm font-bold text-white">{car.power || '300 HP'}</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="text-xs text-slate-400 mb-1">0 - 60 MPH</div>
                  <div className="text-sm font-bold text-white">{car.zeroToSixty || '4.5s'}</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="text-xs text-slate-400 mb-1">Daily Mileage</div>
                  <div className="text-sm font-bold text-white">{car.dailyIncludedMiles} miles/day</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
                  <div className="text-xs text-slate-400 mb-1">Security Deposit</div>
                  <div className="text-sm font-bold text-white">{formatPrice(car.depositAmount)} (Refundable)</div>
                </div>
              </div>
            </div>

            {/* Included Equipment & Features */}
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3">Key Amenities & Tech</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {car.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-2 p-2.5 rounded-xl bg-black/30 backdrop-blur-md border border-white/10 text-xs text-slate-200">
                    <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* DrivePulse Guarantees */}
            <div className="p-4 rounded-2xl bg-amber-500/10 backdrop-blur-md border border-amber-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-8 h-8 text-amber-400 shrink-0" />
                <div>
                  <div className="text-sm font-bold text-white">DrivePulse Certified Inspection</div>
                  <div className="text-xs text-slate-300">Sanitized cabin, tested tires & 100% full fuel/battery before handover.</div>
                </div>
              </div>
            </div>
          </div>

          {/* Modal Sticky Bottom Action Bar */}
          <div className="p-4 sm:p-6 border-t border-white/10 bg-slate-950/60 backdrop-blur-xl flex items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-400">Total rate starts from</span>
              <div className="text-2xl font-black text-white">{formatPrice(car.pricePerDay)} <span className="text-xs font-normal text-slate-400">/day</span></div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setSelectedCarForDetails(null)}
                className="px-5 py-3 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/10 text-sm font-semibold text-slate-300 transition-colors cursor-pointer"
              >
                Close
              </button>

              <button
                disabled={!car.isAvailable}
                onClick={handleBookNow}
                className={`px-8 py-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-lg cursor-pointer ${
                  car.isAvailable
                    ? 'bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 shadow-amber-500/25 active:scale-95 border border-amber-300/30'
                    : 'bg-white/[0.05] border border-white/10 text-slate-500 cursor-not-allowed'
                }`}
              >
                <CalendarCheck className="w-4 h-4" />
                <span>{car.isAvailable ? 'Proceed to Booking' : 'Currently Unavailable'}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
