import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { Car, CarCategory, FuelType, TransmissionType, AvailabilityStatus } from '../types';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  RotateCcw, 
  DollarSign, 
  Car as CarIcon, 
  CheckCircle, 
  AlertTriangle, 
  X, 
  Sparkles,
  TrendingUp,
  Settings,
  Layers,
  Image as ImageIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const FleetManagement: React.FC = () => {
  const { 
    cars, 
    addCar, 
    updateCar, 
    deleteCar, 
    resetDefaultFleet, 
    formatPrice, 
    bookings, 
    showToast 
  } = useRental();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingCar, setEditingCar] = useState<Car | null>(null);

  // Form states for adding a car
  const [newCar, setNewCar] = useState({
    name: '',
    brand: '',
    model: '',
    year: 2024,
    category: 'SUV' as Exclude<CarCategory, 'All'>,
    pricePerDay: 85,
    fuelType: 'Hybrid' as Exclude<FuelType, 'All'>,
    transmission: 'Automatic' as Exclude<TransmissionType, 'All'>,
    seats: 5,
    doors: 4,
    luggage: 3,
    mileage: '35 MPG',
    power: '280 HP',
    zeroToSixty: '5.2s',
    isAvailable: true,
    status: 'Available' as AvailabilityStatus,
    featured: false,
    image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80',
    description: 'Clean, reliable, and modern vehicle equipped with state-of-the-art navigation and safety features.',
    featuresText: 'GPS Navigation, Apple CarPlay, Heated Seats, Bluetooth, Backup Camera',
    location: 'Los Angeles Int. Airport (LAX)',
    dailyIncludedMiles: 250,
    depositAmount: 350,
  });

  // Calculate statistics
  const totalVehicles = cars.length;
  const availableCount = cars.filter((c) => c.status === 'Available').length;
  const activeRentalsCount = bookings.filter((b) => b.status === 'Confirmed' || b.status === 'Active').length;
  const totalBookedRevenue = bookings
    .filter((b) => b.status !== 'Cancelled')
    .reduce((acc, b) => acc + b.totalPrice, 0);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCar.name.trim() || !newCar.brand.trim()) {
      showToast('Please provide a vehicle name and brand', 'error');
      return;
    }

    const features = newCar.featuresText
      .split(',')
      .map((f) => f.trim())
      .filter(Boolean);

    addCar({
      name: newCar.name,
      brand: newCar.brand,
      model: newCar.model || newCar.name,
      year: Number(newCar.year),
      category: newCar.category,
      pricePerDay: Number(newCar.pricePerDay),
      fuelType: newCar.fuelType,
      transmission: newCar.transmission,
      seats: Number(newCar.seats),
      doors: Number(newCar.doors),
      luggage: Number(newCar.luggage),
      mileage: newCar.mileage,
      power: newCar.power,
      zeroToSixty: newCar.zeroToSixty,
      isAvailable: newCar.status === 'Available',
      status: newCar.status,
      featured: newCar.featured,
      image: newCar.image || 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80',
      gallery: [newCar.image],
      description: newCar.description,
      features: features.length > 0 ? features : ['GPS Navigation', 'Air Conditioning'],
      location: newCar.location,
      dailyIncludedMiles: Number(newCar.dailyIncludedMiles),
      depositAmount: Number(newCar.depositAmount),
    });

    setIsAddModalOpen(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCar) return;

    updateCar(editingCar.id, {
      name: editingCar.name,
      brand: editingCar.brand,
      pricePerDay: Number(editingCar.pricePerDay),
      status: editingCar.status,
      featured: editingCar.featured,
      location: editingCar.location,
    });

    setEditingCar(null);
  };

  return (
    <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Settings className="w-4 h-4" />
            <span>Administrative Control</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Fleet Operations & Vehicle Management
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Add new inventory, adjust pricing in real-time, toggle service status, and track revenue.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={resetDefaultFleet}
            className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restore Defaults</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20 hover:brightness-110 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Add New Vehicle</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
            <CarIcon className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Total Fleet</div>
            <div className="text-2xl font-black text-white">{totalVehicles}</div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Available Now</div>
            <div className="text-2xl font-black text-emerald-400">{availableCount}</div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Active Bookings</div>
            <div className="text-2xl font-black text-blue-400">{activeRentalsCount}</div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Booked Volume</div>
            <div className="text-2xl font-black text-purple-300">{formatPrice(totalBookedRevenue)}</div>
          </div>
        </div>
      </div>

      {/* Fleet Inventory Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-base text-white">Live Fleet Roster ({cars.length})</h3>
          <span className="text-xs text-slate-400">Manage status, daily pricing, and catalog entries</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/70 uppercase text-[10px] font-bold tracking-wider text-slate-400 border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Vehicle</th>
                <th className="px-5 py-3.5">Category</th>
                <th className="px-5 py-3.5">Rate / Day</th>
                <th className="px-5 py-3.5">Fuel & Trans</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {cars.map((car) => (
                <tr key={car.id} className="hover:bg-slate-800/40 transition-colors">
                  {/* Vehicle */}
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <img
                        src={car.image}
                        alt={car.name}
                        referrerPolicy="no-referrer"
                        className="w-14 h-10 object-cover rounded-lg bg-slate-950 border border-slate-800 shrink-0"
                      />
                      <div>
                        <div className="font-bold text-white text-sm">{car.name}</div>
                        <div className="text-[11px] text-slate-400">{car.brand} • {car.year}</div>
                      </div>
                    </div>
                  </td>

                  {/* Category */}
                  <td className="px-5 py-3.5">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 font-medium">
                      {car.category}
                    </span>
                  </td>

                  {/* Rate */}
                  <td className="px-5 py-3.5 font-bold text-amber-400 text-sm">
                    {formatPrice(car.pricePerDay)}
                  </td>

                  {/* Specs */}
                  <td className="px-5 py-3.5 text-slate-400">
                    <div>{car.fuelType}</div>
                    <div className="text-[10px]">{car.transmission}</div>
                  </td>

                  {/* Status Toggle Selector */}
                  <td className="px-5 py-3.5">
                    <select
                      value={car.status}
                      onChange={(e) =>
                        updateCar(car.id, { status: e.target.value as AvailabilityStatus })
                      }
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold border focus:outline-none cursor-pointer ${
                        car.status === 'Available'
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                          : car.status === 'Reserved'
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                          : 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                      }`}
                    >
                      <option value="Available" className="bg-slate-900 text-emerald-400">Available</option>
                      <option value="Reserved" className="bg-slate-900 text-amber-400">Reserved</option>
                      <option value="Maintenance" className="bg-slate-900 text-rose-400">Maintenance</option>
                    </select>
                  </td>

                  {/* Action Buttons */}
                  <td className="px-5 py-3.5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setEditingCar(car)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                        aria-label="Edit Car"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => deleteCar(car.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400"
                        aria-label="Delete Car"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add New Car Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={() => setIsAddModalOpen(false)} />

          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl z-10 my-auto max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
              <h3 className="text-lg font-bold text-white">Add New Vehicle to Fleet</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Vehicle Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mercedes-Benz AMG GT"
                    value={newCar.name}
                    onChange={(e) => setNewCar({ ...newCar, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Brand *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mercedes-Benz"
                    value={newCar.brand}
                    onChange={(e) => setNewCar({ ...newCar, brand: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Category</label>
                  <select
                    value={newCar.category}
                    onChange={(e) => setNewCar({ ...newCar, category: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none"
                  >
                    <option value="SUV">SUV</option>
                    <option value="Sedan">Sedan</option>
                    <option value="Luxury">Luxury</option>
                    <option value="Electric">Electric</option>
                    <option value="Sports">Sports</option>
                    <option value="Compact">Compact</option>
                    <option value="Van">Van</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Price / Day ($) *</label>
                  <input
                    type="number"
                    min={20}
                    value={newCar.pricePerDay}
                    onChange={(e) => setNewCar({ ...newCar, pricePerDay: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Year</label>
                  <input
                    type="number"
                    value={newCar.year}
                    onChange={(e) => setNewCar({ ...newCar, year: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Fuel Type</label>
                  <select
                    value={newCar.fuelType}
                    onChange={(e) => setNewCar({ ...newCar, fuelType: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none"
                  >
                    <option value="Petrol">Petrol</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="Electric">Electric</option>
                    <option value="Diesel">Diesel</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Transmission</label>
                  <select
                    value={newCar.transmission}
                    onChange={(e) => setNewCar({ ...newCar, transmission: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none"
                  >
                    <option value="Automatic">Automatic</option>
                    <option value="Manual">Manual</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Seats</label>
                  <input
                    type="number"
                    value={newCar.seats}
                    onChange={(e) => setNewCar({ ...newCar, seats: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Image URL (Unsplash or direct URL)</label>
                <input
                  type="url"
                  value={newCar.image}
                  onChange={(e) => setNewCar({ ...newCar, image: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Features (Comma separated)</label>
                <input
                  type="text"
                  value={newCar.featuresText}
                  onChange={(e) => setNewCar({ ...newCar, featuresText: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="featured-checkbox"
                  checked={newCar.featured}
                  onChange={(e) => setNewCar({ ...newCar, featured: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 bg-slate-950"
                />
                <label htmlFor="featured-checkbox" className="text-slate-300 cursor-pointer">
                  Highlight in Featured Vehicles Section
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 shadow-md shadow-amber-500/20"
                >
                  Add Vehicle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Car Modal */}
      {editingCar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={() => setEditingCar(null)} />

          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl z-10 my-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">Edit {editingCar.name}</h3>
              <button onClick={() => setEditingCar(null)} className="p-1 rounded-full text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Vehicle Name</label>
                <input
                  type="text"
                  value={editingCar.name}
                  onChange={(e) => setEditingCar({ ...editingCar, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Daily Rental Rate ($)</label>
                <input
                  type="number"
                  value={editingCar.pricePerDay}
                  onChange={(e) => setEditingCar({ ...editingCar, pricePerDay: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Status</label>
                <select
                  value={editingCar.status}
                  onChange={(e) => setEditingCar({ ...editingCar, status: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                >
                  <option value="Available">Available</option>
                  <option value="Reserved">Reserved</option>
                  <option value="Maintenance">Maintenance</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="edit-featured-check"
                  checked={editingCar.featured}
                  onChange={(e) => setEditingCar({ ...editingCar, featured: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 bg-slate-950"
                />
                <label htmlFor="edit-featured-check" className="text-slate-300 cursor-pointer">
                  Featured on Homepage
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingCar(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
