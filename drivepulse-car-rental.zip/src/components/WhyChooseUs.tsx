import React from 'react';
import { 
  ShieldCheck, 
  DollarSign, 
  Clock, 
  Sparkles, 
  Car, 
  MapPin, 
  Headphones, 
  BadgeCheck 
} from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const perks = [
    {
      icon: DollarSign,
      title: 'Transparent Pricing Guarantee',
      description: 'Zero hidden insurance charges or airport counter surprises. What you see is exactly what you pay.',
    },
    {
      icon: ShieldCheck,
      title: '100% Free 24h Cancellation',
      description: 'Plans change. Cancel or reschedule your reservation with full refund up to 24 hours prior to pickup.',
    },
    {
      icon: Sparkles,
      title: 'Showroom Clean & Inspected',
      description: 'Every vehicle undergoes our rigorous 40-point safety check, full detailing, and sanitization before handover.',
    },
    {
      icon: Headphones,
      title: '24/7 Dedicated Support',
      description: 'Our roadside assistance team and dedicated trip managers are available around the clock via phone and app.',
    },
    {
      icon: Car,
      title: 'Newest Fleet Models',
      description: 'Drive the latest 2023–2024 models equipped with modern infotainment, ADAS safety, and wireless connectivity.',
    },
    {
      icon: MapPin,
      title: 'Flexible Airport & City Hubs',
      description: 'Convenient pickup and drop-off at major airport terminals, downtown luxury hotels, and train stations.',
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-slate-900/40 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2 block">
            Why Choose DrivePulse
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Built for Discerning Drivers Who Value Reliability
          </h2>
          <p className="text-sm text-slate-400 mt-2">
            Experience car rental the way it should be: premium, transparent, and completely effortless.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {perks.map((perk, i) => (
            <div
              key={i}
              className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 transition-all flex items-start gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <perk.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white mb-1">{perk.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{perk.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
