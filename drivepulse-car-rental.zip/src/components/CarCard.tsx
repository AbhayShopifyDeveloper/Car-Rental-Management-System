import React from 'react';
import { Car } from '../types';
import { useRental } from '../context/RentalContext';
import { 
  Users, 
  Fuel, 
  Zap, 
  Gauge, 
  Heart, 
  Star, 
  Check, 
  AlertTriangle,
  ArrowRight,
  Info,
  Sparkles
} from 'lucide-react';
import { motion } from 'motion/react';

interface CarCardProps {
  car: Car;
  viewMode?: 'grid' | 'list';
}

export const CarCard: React.FC<CarCardProps> = ({ car, viewMode = 'grid' }) => {
  const { 
    formatPrice, 
    toggleFavorite, 
    isFavorite, 
    setSelectedCarForDetails, 
    setSelectedCarForBooking 
  } = useRental();

  const favorite = isFavorite(car.id);

  if (viewMode === 'list') {
    return (
      <div 
        id={`car-card-${car.id}`}
        className="group bg-slate-900/40 hover:bg-slate-900/60 backdrop-blur-xl border border-white/10 hover:border-amber-400/40 rounded-3xl p-4 sm:p-5 transition-all shadow-[0_8px_30px_rgba(0,0,0,0.3)] hover:shadow-[0_12px_40px_rgba(0,0,0,0.5)] flex flex-col md:flex-row gap-5 items-stretch"
      >
        {/* Left: Image Container */}
        <div className="relative md:w-72 h-48 sm:h-52 shrink-0 rounded-2xl overflow-hidden bg-slate-950/80 border border-white/10">
          <img
            src={car.image}
            alt={car.name}
            loading="lazy"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

          {/* Badges on image */}
          <div className="absolute top-3 left-3 flex items-center gap-1.5">
            <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-950/70 text-amber-400 border border-white/15 backdrop-blur-xl">
              {car.category}
            </span>
            {car.featured && (
              <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-amber-500 text-slate-950 flex items-center gap-1 shadow-sm">
                <Sparkles className="w-3 h-3" /> Featured
              </span>
            )}
          </div>

          <button
            id={`fav-btn-${car.id}`}
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(car.id);
            }}
            className="absolute top-3 right-3 p-2 rounded-full bg-slate-950/60 hover:bg-slate-900/90 border border-white/15 backdrop-blur-xl text-slate-300 hover:text-rose-400 transition-colors cursor-pointer"
            aria-label="Save to favorites"
          >
            <Heart className={`w-4 h-4 ${favorite ? 'fill-rose-500 text-rose-500' : ''}`} />
          </button>

          <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-xs text-amber-300 font-semibold bg-slate-950/70 backdrop-blur-xl px-2.5 py-1 rounded-lg border border-white/10">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{car.rating.toFixed(1)}</span>
            <span className="text-slate-400 text-[10px]">({car.reviewsCount})</span>
          </div>
        </div>

        {/* Middle: Details & Specs */}
        <div className="flex-1 flex flex-col justify-between py-1">
          <div>
            <div className="flex items-start justify-between gap-2 mb-1.5">
              <div>
                <span className="text-xs font-semibold text-slate-400">{car.brand} • {car.year}</span>
                <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                  {car.name}
                </h3>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-semibold shrink-0 border backdrop-blur-md ${
                car.status === 'Available'
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : car.status === 'Reserved'
                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
              }`}>
                {car.status}
              </span>
            </div>

            <p className="text-xs text-slate-300 line-clamp-2 mb-3">
              {car.description}
            </p>

            {/* Spec Chips */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
                <Users className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{car.seats} Seats</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
                {car.fuelType === 'Electric' ? (
                  <Zap className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <Fuel className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <span>{car.fuelType}</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
                <Gauge className="w-4 h-4 text-blue-400 shrink-0" />
                <span>{car.transmission}</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
                <span className="font-semibold text-amber-400 text-[11px]">MPG</span>
                <span>{car.mileage}</span>
              </div>
            </div>

            {/* Features Tags */}
            <div className="flex flex-wrap gap-1.5">
              {car.features.slice(0, 3).map((f, i) => (
                <span key={i} className="text-[11px] text-slate-400 bg-white/[0.04] backdrop-blur-sm border border-white/5 px-2 py-0.5 rounded-md">
                  {f}
                </span>
              ))}
              {car.features.length > 3 && (
                <span className="text-[11px] text-amber-400/90 px-1 py-0.5 font-medium">
                  +{car.features.length - 3} more
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right: Pricing & CTA */}
        <div className="md:w-56 shrink-0 md:border-l md:border-white/10 md:pl-5 flex flex-row md:flex-col justify-between items-center md:items-end pt-3 md:pt-0 border-t md:border-t-0 border-white/10">
          <div className="text-left md:text-right">
            <div className="text-xs text-slate-400 font-medium">Daily Rate</div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-white">
                {formatPrice(car.pricePerDay)}
              </span>
              <span className="text-xs text-slate-400">/day</span>
            </div>
            <div className="text-[11px] text-emerald-400 mt-0.5">Free Cancellation</div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-full mt-3">
            <button
              id={`view-details-${car.id}`}
              onClick={() => setSelectedCarForDetails(car)}
              className="flex-1 px-3 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-200 transition-all cursor-pointer backdrop-blur-md"
            >
              Specs
            </button>
            <button
              id={`book-car-${car.id}`}
              disabled={!car.isAvailable}
              onClick={() => setSelectedCarForBooking(car)}
              className={`flex-1 px-4 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                car.isAvailable
                  ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 shadow-md shadow-amber-500/20 hover:brightness-110 border border-amber-300/30'
                  : 'bg-slate-800/60 text-slate-500 cursor-not-allowed border border-white/5'
              }`}
            >
              <span>{car.isAvailable ? 'Book' : 'Reserved'}</span>
              {car.isAvailable && <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Grid Mode
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      id={`car-card-${car.id}`}
      className="group bg-slate-900/40 hover:bg-slate-900/60 backdrop-blur-xl border border-white/10 hover:border-amber-400/40 rounded-3xl overflow-hidden transition-all shadow-[0_8px_30px_rgba(0,0,0,0.3)] hover:shadow-[0_16px_40px_rgba(0,0,0,0.5)] flex flex-col justify-between"
    >
      {/* Top Media Section */}
      <div className="relative h-52 bg-slate-950/80 overflow-hidden cursor-pointer" onClick={() => setSelectedCarForDetails(car)}>
        <img
          src={car.image}
          alt={car.name}
          loading="lazy"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-black/30" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-950/70 text-amber-400 border border-white/15 backdrop-blur-xl shadow-sm">
            {car.category}
          </span>
          {car.featured && (
            <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-amber-500 text-slate-950 flex items-center gap-1 shadow-sm">
              <Sparkles className="w-3 h-3" /> Featured
            </span>
          )}
        </div>

        {/* Favorite Button */}
        <button
          id={`fav-btn-${car.id}`}
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(car.id);
          }}
          className="absolute top-3 right-3 p-2 rounded-full bg-slate-950/60 hover:bg-slate-900/90 border border-white/15 backdrop-blur-xl text-slate-300 hover:text-rose-400 transition-colors cursor-pointer"
          aria-label="Save vehicle"
        >
          <Heart className={`w-4 h-4 ${favorite ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>

        {/* Bottom image metadata: Rating & Year */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
          <div className="flex items-center gap-1 text-xs text-amber-300 font-semibold bg-slate-950/70 backdrop-blur-xl px-2 py-0.5 rounded-lg border border-white/10">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{car.rating.toFixed(1)}</span>
            <span className="text-slate-400 text-[10px]">({car.reviewsCount})</span>
          </div>

          <span className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold border backdrop-blur-xl ${
            car.status === 'Available'
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
              : car.status === 'Reserved'
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
          }`}>
            {car.status}
          </span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>{car.brand}</span>
            <span>{car.year}</span>
          </div>

          <h3 
            onClick={() => setSelectedCarForDetails(car)}
            className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors mb-3 cursor-pointer line-clamp-1"
          >
            {car.name}
          </h3>

          {/* Quick Specifications Grid */}
          <div className="grid grid-cols-2 gap-2 mb-4">
            <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
              <Users className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{car.seats} Seats</span>
            </div>

            <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
              {car.fuelType === 'Electric' ? (
                <Zap className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              ) : (
                <Fuel className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              )}
              <span>{car.fuelType}</span>
            </div>

            <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
              <Gauge className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>{car.transmission}</span>
            </div>

            <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] backdrop-blur-md border border-white/10 text-xs text-slate-300">
              <span className="font-bold text-amber-400 text-[10px]">MPG</span>
              <span className="truncate">{car.mileage}</span>
            </div>
          </div>
        </div>

        {/* Card Footer: Pricing & Action Buttons */}
        <div className="pt-3 border-t border-white/10">
          <div className="flex items-baseline justify-between mb-3">
            <div>
              <span className="text-2xl font-extrabold text-white">
                {formatPrice(car.pricePerDay)}
              </span>
              <span className="text-xs text-slate-400 ml-1">/day</span>
            </div>
            <div className="text-[11px] text-emerald-400 flex items-center gap-1">
              <Check className="w-3 h-3" /> Inc. Insurance Opt.
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <button
              id={`details-btn-${car.id}`}
              onClick={() => setSelectedCarForDetails(car)}
              className="col-span-1 py-2.5 px-2 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-200 transition-all text-center cursor-pointer backdrop-blur-md"
            >
              Details
            </button>

            <button
              id={`book-btn-${car.id}`}
              disabled={!car.isAvailable}
              onClick={() => setSelectedCarForBooking(car)}
              className={`col-span-2 py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                car.isAvailable
                  ? 'bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 shadow-md shadow-amber-500/20 active:scale-95 border border-amber-300/30'
                  : 'bg-slate-800/60 text-slate-500 cursor-not-allowed border border-white/5'
              }`}
            >
              <span>{car.isAvailable ? 'Book Now' : 'Reserved'}</span>
              {car.isAvailable && <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
