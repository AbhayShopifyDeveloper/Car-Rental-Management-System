import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { BookingStatus } from '../types';
import { 
  CalendarCheck, 
  Search, 
  Printer, 
  AlertCircle, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Car, 
  ArrowRight,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { motion } from 'motion/react';

export const MyBookings: React.FC = () => {
  const { 
    bookings, 
    cancelBooking, 
    setViewingReceipt, 
    formatPrice, 
    setActiveTab,
    showToast 
  } = useRental();

  const [statusFilter, setStatusFilter] = useState<'All' | BookingStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  const filteredBookings = bookings.filter((b) => {
    if (statusFilter !== 'All' && b.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        b.bookingNumber.toLowerCase().includes(q) ||
        b.carName.toLowerCase().includes(q) ||
        b.customerName.toLowerCase().includes(q) ||
        b.pickupLocation.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCancelClick = (bookingId: string) => {
    cancelBooking(bookingId);
    setCancellingId(null);
  };

  return (
    <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <CalendarCheck className="w-4 h-4" />
            <span>Rental Management</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            My Reservations & Trips
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Track active rentals, access digital vouchers, and manage trip itineraries.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('fleet')}
          className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 self-start md:self-auto cursor-pointer"
        >
          <span>Book Another Vehicle</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 mb-8 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        {/* Status Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {(['All', 'Confirmed', 'Completed', 'Cancelled'] as const).map((status) => {
            const count = status === 'All' 
              ? bookings.length 
              : bookings.filter((b) => b.status === status).length;

            return (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                  statusFilter === status
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm shadow-amber-500/20'
                    : 'bg-slate-950/70 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {status} ({count})
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search booking #, car name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Bookings List */}
      {filteredBookings.length > 0 ? (
        <div className="space-y-4">
          {filteredBookings.map((booking) => (
            <motion.div
              key={booking.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 transition-all shadow-lg flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6"
            >
              {/* Left: Car Media & Basic Details */}
              <div className="flex items-center gap-4">
                <img
                  src={booking.carImage}
                  alt={booking.carName}
                  referrerPolicy="no-referrer"
                  className="w-24 h-18 sm:w-28 sm:h-20 object-cover rounded-xl border border-slate-800 bg-slate-950 shrink-0"
                />

                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-xs font-bold text-amber-400">
                      {booking.bookingNumber}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      booking.status === 'Confirmed' || booking.status === 'Active'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                    }`}>
                      {booking.status}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-bold text-white mb-1">
                    {booking.carName}
                  </h3>

                  <div className="text-xs text-slate-400 flex items-center gap-3">
                    <span>Driver: <strong className="text-slate-200">{booking.customerName}</strong></span>
                    <span>•</span>
                    <span>{booking.totalDays} Days ({formatPrice(booking.totalPrice)})</span>
                  </div>
                </div>
              </div>

              {/* Middle: Pickup / Return Itinerary */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 w-full lg:w-auto">
                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-amber-400" /> Pick-up
                  </span>
                  <div className="text-slate-200 font-semibold truncate max-w-xs">{booking.pickupLocation}</div>
                  <div className="text-amber-400 text-[11px]">{booking.pickupDate} at {booking.pickupTime}</div>
                </div>

                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-emerald-400" /> Return
                  </span>
                  <div className="text-slate-200 font-semibold truncate max-w-xs">{booking.dropoffLocation}</div>
                  <div className="text-amber-400 text-[11px]">{booking.dropoffDate} at {booking.dropoffTime}</div>
                </div>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-2.5 self-end lg:self-center shrink-0 w-full sm:w-auto justify-end">
                <button
                  onClick={() => setViewingReceipt(booking)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Invoice</span>
                </button>

                {booking.status === 'Confirmed' && (
                  cancellingId === booking.id ? (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCancelClick(booking.id)}
                        className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors"
                      >
                        Confirm Cancel
                      </button>
                      <button
                        onClick={() => setCancellingId(null)}
                        className="px-2.5 py-2 rounded-xl bg-slate-800 text-slate-400 text-xs hover:text-white"
                      >
                        No
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setCancellingId(booking.id)}
                      className="px-3.5 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Cancel Trip
                    </button>
                  )
                )}
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 px-4 bg-slate-900/40 rounded-3xl border border-slate-800">
          <CalendarCheck className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-xl font-bold text-white mb-2">No Bookings Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-6">
            You don't have any bookings matching this criteria yet. Discover our premium fleet to get started!
          </p>
          <button
            onClick={() => setActiveTab('fleet')}
            className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-all shadow-md shadow-amber-500/20"
          >
            Explore Fleet Now
          </button>
        </div>
      )}
    </section>
  );
};
