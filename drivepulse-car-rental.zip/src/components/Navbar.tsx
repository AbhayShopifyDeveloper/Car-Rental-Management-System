import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { CurrencyCode } from '../types';
import { CURRENCIES } from '../data/carsData';
import { 
  Car, 
  CalendarCheck, 
  SlidersHorizontal, 
  Menu, 
  X, 
  Sparkles, 
  PhoneCall, 
  ShieldCheck, 
  Globe,
  Settings
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { activeTab, setActiveTab, bookings, currency, setCurrency } = useRental();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  const activeBookingsCount = bookings.filter((b) => b.status === 'Confirmed' || b.status === 'Active').length;

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'fleet', label: 'Vehicles & Fleet' },
    { id: 'bookings', label: 'My Bookings', badge: activeBookingsCount > 0 ? activeBookingsCount : undefined },
    { id: 'about', label: 'How It Works' },
    { id: 'admin', label: 'Admin Fleet', icon: Settings },
  ];

  const handleNavClick = (tabId: 'home' | 'fleet' | 'bookings' | 'admin' | 'about') => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-2xl bg-slate-950/70 border-b border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.3)] transition-all">
      {/* Top micro-bar for emergency & trust */}
      <div className="bg-white/[0.02] backdrop-blur-md border-b border-white/5 py-1.5 px-4 text-xs text-slate-400 hidden sm:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-slate-300">
              <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
              24/7 Roadside Assistance: <strong className="text-white">+1 (800) 555-DRIVE</strong>
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Free Cancellation up to 24h before pickup
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-amber-400/90 font-medium">Use code <strong>DRIVE15</strong> for 15% OFF today</span>
          </div>
        </div>
      </div>

      {/* Main navigation bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <button
          id="nav-brand-logo-btn"
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 group text-left cursor-pointer focus:outline-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center shadow-lg shadow-amber-500/25 group-hover:scale-105 transition-transform backdrop-blur-md border border-white/20">
            <Car className="w-6 h-6 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xl tracking-tight text-white font-serif">DrivePulse</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 backdrop-blur-md">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-slate-400 tracking-wide font-medium">Car Rental & Fleet Hub</p>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 bg-white/[0.04] backdrop-blur-xl p-1.5 rounded-full border border-white/10 shadow-inner">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => handleNavClick(item.id as any)}
                className={`relative px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/30'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                {item.icon && <item.icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-amber-400'}`} />}
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span
                    className={`text-xs px-1.5 py-0.2 rounded-full font-bold ${
                      isActive ? 'bg-slate-950 text-amber-400' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right action group: Currency Selector + Quick CTA */}
        <div className="flex items-center gap-3">
          {/* Currency Dropdown */}
          <div className="relative">
            <button
              id="currency-selector-toggle"
              onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.05] backdrop-blur-xl border border-white/10 text-xs font-semibold text-slate-200 hover:border-white/20 hover:bg-white/10 transition-all shadow-sm"
            >
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <span>{currency}</span>
              <span className="text-amber-400 text-[11px] font-bold">{CURRENCIES[currency].symbol}</span>
            </button>

            {currencyDropdownOpen && (
              <div className="absolute right-0 mt-2 w-36 py-1.5 bg-slate-900/90 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-2xl z-50 animate-in fade-in zoom-in-95">
                {(Object.keys(CURRENCIES) as CurrencyCode[]).map((code) => (
                  <button
                    key={code}
                    onClick={() => {
                      setCurrency(code);
                      setCurrencyDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3.5 py-1.5 text-xs flex items-center justify-between hover:bg-white/10 transition-colors ${
                      currency === code ? 'text-amber-400 font-bold bg-white/10' : 'text-slate-300'
                    }`}
                  >
                    <span>{code}</span>
                    <span className="text-slate-400 font-mono">{CURRENCIES[code].symbol}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Direct CTA */}
          <button
            id="nav-quick-book-cta"
            onClick={() => handleNavClick('fleet')}
            className="hidden sm:inline-flex items-center gap-2 px-4.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-sm hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-amber-500/25 border border-amber-300/30 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>Browse Fleet</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl bg-white/[0.05] backdrop-blur-xl border border-white/10 text-slate-300 hover:text-white"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-slate-950/90 backdrop-blur-2xl px-4 py-5 space-y-3 animate-in slide-in-from-top-4 duration-200">
          <div className="space-y-1">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  onClick={() => handleNavClick(item.id as any)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-base font-medium transition-all ${
                    isActive ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-200 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {item.icon && <item.icon className="w-4 h-4" />}
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                        isActive ? 'bg-slate-950 text-amber-400' : 'bg-amber-500 text-slate-950'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-3">
            <button
              onClick={() => handleNavClick('fleet')}
              className="w-full py-3 rounded-xl bg-amber-500 text-slate-950 font-bold text-center shadow-lg shadow-amber-500/20"
            >
              Explore All Rental Cars
            </button>
            <div className="flex items-center justify-between text-xs text-slate-400 px-2">
              <span>Roadside support: 24/7</span>
              <span>100% Guaranteed Availability</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
