import React from 'react';
import { useRental } from '../context/RentalContext';
import { QuickSearchWidget } from './QuickSearchWidget';
import { ShieldCheck, Award, Zap, Users, Star, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

export const Hero: React.FC = () => {
  const { setActiveTab } = useRental();

  return (
    <section className="relative pt-12 pb-20 lg:pt-16 lg:pb-28 overflow-hidden">
      {/* Ambient lighting gradients */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-amber-500/15 blur-[140px] rounded-full pointer-events-none" />
      <div className="absolute top-1/2 right-10 w-[450px] h-[350px] bg-blue-500/10 blur-[130px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-10">
          {/* Top trust pill */}
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/[0.06] border border-white/15 text-amber-300 text-xs font-semibold mb-6 backdrop-blur-2xl shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span>Summer Roadtrip Deals: Up to 20% Off Luxury & SUV Fleet</span>
          </motion.div>

          {/* Main Headline */}
          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.15] mb-6"
          >
            Drive the Road Ahead with <span className="bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 bg-clip-text text-transparent drop-shadow-sm">Premium Comfort</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto mb-8 font-normal"
          >
            Choose from an elite fleet of electric, sports, luxury, and family vehicles. Instant digital reservation, transparent pricing, and 24/7 roadside peace of mind.
          </motion.p>

          {/* Quick CTA links */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap items-center justify-center gap-4 mb-8"
          >
            <button
              id="hero-explore-fleet-btn"
              onClick={() => {
                setActiveTab('fleet');
                setTimeout(() => {
                  document.getElementById('fleet-section')?.scrollIntoView({ behavior: 'smooth' });
                }, 50);
              }}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-sm hover:from-amber-400 hover:to-amber-300 transition-all flex items-center gap-2 shadow-lg shadow-amber-500/25 border border-amber-300/30 active:scale-95 cursor-pointer"
            >
              <span>Explore All Vehicles</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              id="hero-how-it-works-btn"
              onClick={() => setActiveTab('about')}
              className="px-6 py-3 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/15 text-slate-200 font-semibold text-sm backdrop-blur-xl transition-all shadow-sm cursor-pointer"
            >
              How It Works
            </button>
          </motion.div>
        </div>

        {/* Quick Search Widget Container */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-16"
        >
          <QuickSearchWidget />
        </motion.div>

        {/* Trust Badges Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto pt-6 border-t border-white/10">
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/25 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="font-bold text-sm text-white">$0 Hidden Fees</div>
              <div className="text-xs text-slate-400">100% upfront pricing</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center shrink-0">
              <Award className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="font-bold text-sm text-white">4.9/5 Rating</div>
              <div className="text-xs text-slate-400">Over 25,000+ happy trips</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]">
            <div className="w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/25 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <div className="font-bold text-sm text-white">Instant Booking</div>
              <div className="text-xs text-slate-400">Keyless digital pickup</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]">
            <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/25 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="font-bold text-sm text-white">24/7 Support</div>
              <div className="text-xs text-slate-400">Roadside assistance</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
