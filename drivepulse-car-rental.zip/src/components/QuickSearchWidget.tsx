import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { LOCATIONS } from '../data/carsData';
import { CarCategory } from '../types';
import { MapPin, Calendar, Clock, Sparkles, ArrowRight, Check } from 'lucide-react';

interface QuickSearchWidgetProps {
  compact?: boolean;
}

export const QuickSearchWidget: React.FC<QuickSearchWidgetProps> = ({ compact = false }) => {
  const { 
    quickSearchParams, 
    setQuickSearchParams, 
    setFilters, 
    setActiveTab, 
    showToast 
  } = useRental();

  const [sameLocation, setSameLocation] = useState(true);
  const [pickupTime, setPickupTime] = useState('10:00 AM');
  const [dropoffTime, setDropoffTime] = useState('10:00 AM');

  const categories: CarCategory[] = ['All', 'SUV', 'Sedan', 'Luxury', 'Electric', 'Sports', 'Compact'];

  const timeOptions = [
    '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM'
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();

    const start = new Date(quickSearchParams.pickupDate);
    const end = new Date(quickSearchParams.dropoffDate);

    if (end <= start) {
      showToast('Drop-off date must be after pick-up date', 'error');
      return;
    }

    // Apply category filter if not 'All'
    setFilters((prev) => ({
      ...prev,
      category: quickSearchParams.category as CarCategory,
      onlyAvailable: true,
    }));

    setActiveTab('fleet');
    showToast(`Found available ${quickSearchParams.category === 'All' ? 'cars' : quickSearchParams.category + ' vehicles'}!`, 'success');

    // Scroll to cars section
    setTimeout(() => {
      const element = document.getElementById('fleet-section');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className={`w-full bg-slate-900/50 backdrop-blur-2xl rounded-3xl border border-white/15 shadow-[0_12px_40px_rgba(0,0,0,0.45)] p-4 sm:p-7 transition-all relative overflow-hidden ${compact ? 'max-w-4xl mx-auto' : ''}`}>
      {/* Subtle top sheen */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />

      <form onSubmit={handleSearch} className="space-y-5">
        {/* Category Pills Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider shrink-0 mr-1">
            Category:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              id={`quick-filter-cat-${cat.toLowerCase()}`}
              onClick={() => setQuickSearchParams((prev) => ({ ...prev, category: cat }))}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all shrink-0 cursor-pointer ${
                quickSearchParams.category === cat
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/30'
                  : 'bg-white/[0.04] backdrop-blur-md text-slate-300 hover:bg-white/10 hover:text-white border border-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Form Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Pickup Location */}
          <div className="bg-black/40 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 focus-within:border-amber-400/60 focus-within:bg-black/60 transition-all">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              Pick-up Location
            </label>
            <select
              id="quick-pickup-location"
              value={quickSearchParams.pickupLocation}
              onChange={(e) => {
                const val = e.target.value;
                setQuickSearchParams((prev) => ({
                  ...prev,
                  pickupLocation: val,
                  dropoffLocation: sameLocation ? val : prev.dropoffLocation,
                }));
              }}
              className="w-full bg-transparent text-sm text-slate-100 font-medium focus:outline-none cursor-pointer"
            >
              {LOCATIONS.map((loc) => (
                <option key={loc.id} value={loc.name} className="bg-slate-900 text-slate-200">
                  {loc.name}
                </option>
              ))}
            </select>
          </div>

          {/* Drop-off Location */}
          <div className="bg-black/40 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 focus-within:border-amber-400/60 focus-within:bg-black/60 transition-all">
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                Return Location
              </label>
              <button
                type="button"
                onClick={() => {
                  const nextSame = !sameLocation;
                  setSameLocation(nextSame);
                  if (nextSame) {
                    setQuickSearchParams((prev) => ({ ...prev, dropoffLocation: prev.pickupLocation }));
                  }
                }}
                className="text-[10px] text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                {sameLocation ? (
                  <span className="flex items-center text-slate-400 hover:text-amber-300">
                    <Check className="w-3 h-3 text-amber-400 mr-0.5" /> Same
                  </span>
                ) : (
                  'Different'
                )}
              </button>
            </div>
            {sameLocation ? (
              <div className="text-sm text-slate-300 font-medium truncate py-0.5">
                {quickSearchParams.pickupLocation}
              </div>
            ) : (
              <select
                id="quick-dropoff-location"
                value={quickSearchParams.dropoffLocation}
                onChange={(e) =>
                  setQuickSearchParams((prev) => ({ ...prev, dropoffLocation: e.target.value }))
                }
                className="w-full bg-transparent text-sm text-slate-100 font-medium focus:outline-none cursor-pointer"
              >
                {LOCATIONS.map((loc) => (
                  <option key={loc.id} value={loc.name} className="bg-slate-900 text-slate-200">
                    {loc.name}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Pick-up Date & Time */}
          <div className="bg-black/40 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 focus-within:border-amber-400/60 focus-within:bg-black/60 transition-all">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              Pick-up Date & Time
            </label>
            <div className="flex items-center gap-2">
              <input
                type="date"
                id="quick-pickup-date"
                min={new Date().toISOString().split('T')[0]}
                value={quickSearchParams.pickupDate}
                onChange={(e) =>
                  setQuickSearchParams((prev) => ({ ...prev, pickupDate: e.target.value }))
                }
                className="w-full bg-transparent text-sm text-slate-100 font-medium focus:outline-none [color-scheme:dark]"
              />
              <select
                value={pickupTime}
                onChange={(e) => setPickupTime(e.target.value)}
                className="bg-slate-900 border border-white/10 rounded px-1.5 py-0.5 text-xs text-slate-300 focus:outline-none"
              >
                {timeOptions.map((t) => (
                  <option key={t} value={t} className="bg-slate-900">
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Drop-off Date & Time */}
          <div className="bg-black/40 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 focus-within:border-amber-400/60 focus-within:bg-black/60 transition-all">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              Return Date & Time
            </label>
            <div className="flex items-center gap-2">
              <input
                type="date"
                id="quick-dropoff-date"
                min={quickSearchParams.pickupDate || new Date().toISOString().split('T')[0]}
                value={quickSearchParams.dropoffDate}
                onChange={(e) =>
                  setQuickSearchParams((prev) => ({ ...prev, dropoffDate: e.target.value }))
                }
                className="w-full bg-transparent text-sm text-slate-100 font-medium focus:outline-none [color-scheme:dark]"
              />
              <select
                value={dropoffTime}
                onChange={(e) => setDropoffTime(e.target.value)}
                className="bg-slate-900 border border-white/10 rounded px-1.5 py-0.5 text-xs text-slate-300 focus:outline-none"
              >
                {timeOptions.map((t) => (
                  <option key={t} value={t} className="bg-slate-900">
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Submit Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Instant vehicle dispatch & zero cancellation penalties</span>
          </div>

          <button
            type="submit"
            id="quick-search-submit-btn"
            className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-sm hover:from-amber-400 hover:to-amber-300 transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 border border-amber-300/30 active:scale-95 cursor-pointer"
          >
            <span>Search Available Fleet</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </form>
    </div>
  );
};
