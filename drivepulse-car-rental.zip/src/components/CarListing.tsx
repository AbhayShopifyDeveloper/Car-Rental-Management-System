import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { CarCard } from './CarCard';
import { CarCategory, FuelType, TransmissionType } from '../types';
import { 
  Search, 
  SlidersHorizontal, 
  RotateCcw, 
  Grid3X3, 
  List, 
  Check, 
  X, 
  Car as CarIcon,
  ChevronDown,
  Sparkles,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const CarListing: React.FC = () => {
  const { 
    filteredCars, 
    filters, 
    setFilters, 
    resetFilters, 
    formatPrice,
    cars
  } = useRental();

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  const categories: CarCategory[] = ['All', 'SUV', 'Sedan', 'Luxury', 'Electric', 'Sports', 'Compact', 'Van'];
  const fuelTypes: FuelType[] = ['All', 'Petrol', 'Hybrid', 'Electric', 'Diesel'];
  const transmissions: TransmissionType[] = ['All', 'Automatic', 'Manual'];

  const isFilterActive = 
    filters.search !== '' ||
    filters.category !== 'All' ||
    filters.fuelType !== 'All' ||
    filters.transmission !== 'All' ||
    filters.minPrice > 0 ||
    filters.maxPrice < 300 ||
    filters.seats !== 'All' ||
    filters.onlyAvailable ||
    filters.sortBy !== 'featured';

  return (
    <section id="fleet-section" className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <CarIcon className="w-4 h-4" />
            <span>Our Premium Fleet</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Explore Vehicles Ready for the Road
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Showing <strong className="text-white">{filteredCars.length}</strong> of {cars.length} available vehicles
          </p>
        </div>

        {/* View Mode & Filter Toggle buttons */}
        <div className="flex items-center gap-2">
          {/* Mobile Filter Toggle */}
          <button
            onClick={() => setShowFilterDrawer(!showFilterDrawer)}
            className={`md:hidden px-3.5 py-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors backdrop-blur-xl ${
              isFilterActive 
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300' 
                : 'bg-white/[0.05] border-white/10 text-slate-300'
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>Filters</span>
            {isFilterActive && <span className="w-2 h-2 rounded-full bg-amber-400" />}
          </button>

          {/* Sort Dropdown */}
          <div className="relative">
            <select
              id="cars-sort-select"
              value={filters.sortBy}
              onChange={(e) => setFilters((prev) => ({ ...prev, sortBy: e.target.value as any }))}
              className="bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-200 focus:border-amber-400/60 focus:outline-none cursor-pointer appearance-none pr-8 shadow-sm"
            >
              <option value="featured" className="bg-slate-900">Sort: Featured First</option>
              <option value="price-asc" className="bg-slate-900">Price: Low to High</option>
              <option value="price-desc" className="bg-slate-900">Price: High to Low</option>
              <option value="rating-desc" className="bg-slate-900">Rating: Highest Rated</option>
              <option value="name-asc" className="bg-slate-900">Alphabetical: A to Z</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Grid / List switcher */}
          <div className="hidden sm:flex items-center bg-white/[0.04] backdrop-blur-xl p-1 rounded-xl border border-white/10">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              aria-label="Grid View"
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'list' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              aria-label="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Search & Quick Filters Bar */}
      <div className="bg-slate-900/50 backdrop-blur-2xl border border-white/15 rounded-3xl p-5 mb-8 space-y-4 shadow-[0_12px_40px_rgba(0,0,0,0.35)] relative overflow-hidden">
        {/* Subtle top sheen */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />

        {/* Search input + Category Pills row */}
        <div className="flex flex-col lg:flex-row items-center gap-3">
          {/* Search Box */}
          <div className="relative w-full lg:w-80 shrink-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="car-search-input"
              placeholder="Search model, brand, features..."
              value={filters.search}
              onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value }))}
              className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl pl-9.5 pr-8 py-2.5 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:border-amber-400/60 focus:bg-black/60 focus:outline-none transition-all"
            />
            {filters.search && (
              <button
                onClick={() => setFilters((prev) => ({ ...prev, search: '' }))}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`fleet-category-${cat.toLowerCase()}`}
                onClick={() => setFilters((prev) => ({ ...prev, category: cat }))}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                  filters.category === cat
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'bg-white/[0.04] backdrop-blur-md text-slate-300 hover:bg-white/10 hover:text-white border border-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Detailed Filters row (Desktop visible or Mobile toggle) */}
        <div className={`pt-3 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 items-center ${showFilterDrawer ? 'block' : 'hidden md:grid'}`}>
          {/* Fuel Type */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Fuel Type</label>
            <select
              id="filter-fuel-type"
              value={filters.fuelType}
              onChange={(e) => setFilters((prev) => ({ ...prev, fuelType: e.target.value as any }))}
              className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              {fuelTypes.map((f) => (
                <option key={f} value={f} className="bg-slate-900">{f}</option>
              ))}
            </select>
          </div>

          {/* Transmission */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Transmission</label>
            <select
              id="filter-transmission"
              value={filters.transmission}
              onChange={(e) => setFilters((prev) => ({ ...prev, transmission: e.target.value as any }))}
              className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              {transmissions.map((t) => (
                <option key={t} value={t} className="bg-slate-900">{t}</option>
              ))}
            </select>
          </div>

          {/* Min Seats */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Seats</label>
            <select
              id="filter-seats"
              value={filters.seats}
              onChange={(e) => {
                const val = e.target.value === 'All' ? 'All' : Number(e.target.value);
                setFilters((prev) => ({ ...prev, seats: val as any }));
              }}
              className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="All" className="bg-slate-900">Any Seating</option>
              <option value="2" className="bg-slate-900">2 Seats</option>
              <option value="4" className="bg-slate-900">4 Seats</option>
              <option value="5" className="bg-slate-900">5 Seats</option>
              <option value="7" className="bg-slate-900">7+ Seats</option>
            </select>
          </div>

          {/* Max Price Range Slider */}
          <div>
            <div className="flex items-center justify-between text-[10px] uppercase font-bold text-slate-400 mb-1">
              <span>Max Price:</span>
              <span className="text-amber-400 text-xs font-mono">{formatPrice(filters.maxPrice)}/day</span>
            </div>
            <input
              type="range"
              id="filter-price-slider"
              min={50}
              max={300}
              step={10}
              value={filters.maxPrice}
              onChange={(e) => setFilters((prev) => ({ ...prev, maxPrice: Number(e.target.value) }))}
              className="w-full h-1.5 bg-black/50 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>

          {/* Availability Checkbox & Reset */}
          <div className="flex items-center justify-between sm:justify-start gap-3 pt-4 sm:pt-2">
            <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer select-none">
              <input
                type="checkbox"
                id="filter-available-only"
                checked={filters.onlyAvailable}
                onChange={(e) => setFilters((prev) => ({ ...prev, onlyAvailable: e.target.checked }))}
                className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 bg-black/40 border-white/20"
              />
              <span>Only Available</span>
            </label>

            {isFilterActive && (
              <button
                onClick={resetFilters}
                id="reset-filters-btn"
                className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 ml-auto cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Car Cards Grid / List */}
      {filteredCars.length > 0 ? (
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
          {filteredCars.map((car) => (
            <CarCard key={car.id} car={car} viewMode={viewMode} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 px-4 bg-slate-900/40 backdrop-blur-xl rounded-3xl border border-white/10 shadow-lg">
          <CarIcon className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <h3 className="text-xl font-bold text-white mb-2">No Vehicles Match Your Search</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-6">
            Try adjusting your search criteria, price range, or category filter to discover available vehicles.
          </p>
          <button
            onClick={resetFilters}
            className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-all shadow-md shadow-amber-500/20 cursor-pointer"
          >
            Clear All Filters
          </button>
        </div>
      )}
    </section>
  );
};
