import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { 
  X, 
  Printer, 
  Copy, 
  Check, 
  Car, 
  MapPin, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  FileCheck2,
  Mail,
  Phone
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ReceiptModal: React.FC = () => {
  const { viewingReceipt, setViewingReceipt, formatPrice, showToast } = useRental();
  const [copied, setCopied] = useState(false);

  if (!viewingReceipt) return null;

  const booking = viewingReceipt;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(booking.bookingNumber);
    setCopied(true);
    showToast('Booking reference copied to clipboard', 'info');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setViewingReceipt(null)}
          className="fixed inset-0 bg-slate-950/85 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-2xl bg-slate-900/60 backdrop-blur-2xl border border-white/15 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.6)] overflow-hidden z-10 my-auto max-h-[92vh] flex flex-col"
        >
          {/* Subtle top sheen */}
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />

          {/* Header */}
          <div className="px-6 py-4 border-b border-white/10 bg-slate-950/60 backdrop-blur-xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-amber-400" />
              <h3 className="text-base font-bold text-white">Rental Confirmation Voucher</h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className="px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer backdrop-blur-md"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print</span>
              </button>
              <button
                onClick={() => setViewingReceipt(null)}
                className="p-1.5 rounded-full bg-white/[0.05] hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Printable Voucher Body */}
          <div id="printable-voucher" className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
            {/* Top Brand Banner */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center font-bold text-slate-950 shadow-md shadow-amber-500/20">
                  <Car className="w-6 h-6 stroke-[2.5]" />
                </div>
                <div>
                  <div className="text-lg font-black text-white font-serif tracking-tight">DrivePulse Rentals</div>
                  <div className="text-[11px] text-slate-400">Official Booking Receipt</div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-[10px] uppercase font-bold text-slate-400">Booking Ref</div>
                <div className="flex items-center gap-1.5 font-mono text-base font-black text-amber-400">
                  <span>{booking.bookingNumber}</span>
                  <button onClick={handleCopyCode} className="text-slate-400 hover:text-white p-1 cursor-pointer">
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400 hover:text-white" />}
                  </button>
                </div>
                <div className="text-[10px] text-slate-500">{new Date(booking.createdAt).toLocaleDateString()}</div>
              </div>
            </div>

            {/* Status & Vehicle row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10">
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400 mb-1">Rented Vehicle</div>
                <div className="text-sm font-bold text-white">{booking.carName}</div>
                <div className="text-xs text-amber-400 font-semibold mt-0.5">
                  {formatPrice(booking.carPricePerDay)}/day • {booking.totalDays} Days
                </div>
              </div>

              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400 mb-1">Booking Status</div>
                <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-bold ${
                  booking.status === 'Confirmed' || booking.status === 'Active'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                }`}>
                  {booking.status}
                </span>
              </div>
            </div>

            {/* Locations & Dates Table */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10 space-y-1">
                <div className="text-[10px] font-bold uppercase text-slate-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-amber-400" /> Pick-up Details
                </div>
                <div className="text-xs font-semibold text-white">{booking.pickupLocation}</div>
                <div className="text-[11px] text-amber-300">{booking.pickupDate} at {booking.pickupTime}</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10 space-y-1">
                <div className="text-[10px] font-bold uppercase text-slate-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-emerald-400" /> Return Details
                </div>
                <div className="text-xs font-semibold text-white">{booking.dropoffLocation}</div>
                <div className="text-[11px] text-amber-300">{booking.dropoffDate} at {booking.dropoffTime}</div>
              </div>
            </div>

            {/* Customer Information */}
            <div className="p-4 rounded-2xl bg-black/30 backdrop-blur-md border border-white/10">
              <div className="text-[10px] font-bold uppercase text-slate-400 mb-2">Driver Record</div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <span className="text-slate-400 block text-[10px]">Name</span>
                  <span className="text-xs font-bold text-white">{booking.customerName}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Email</span>
                  <span className="text-xs font-medium text-slate-200 truncate block">{booking.customerEmail}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">License #</span>
                  <span className="text-xs font-mono font-bold text-amber-400">{booking.licenseNumber}</span>
                </div>
              </div>
            </div>

            {/* Itemized Charges */}
            <div className="p-4 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 space-y-1.5">
              <div className="text-[10px] font-bold uppercase text-slate-400 mb-2">Financial Breakdown</div>

              <div className="flex items-center justify-between">
                <span>Vehicle Base Rate ({booking.totalDays} days)</span>
                <span>{formatPrice(booking.carPricePerDay * booking.totalDays)}</span>
              </div>

              {booking.addOnsCost > 0 && (
                <div className="flex items-center justify-between">
                  <span>Selected Add-ons & Coverage</span>
                  <span>+{formatPrice(booking.addOnsCost)}</span>
                </div>
              )}

              {booking.discountAmount > 0 && (
                <div className="flex items-center justify-between text-emerald-400">
                  <span>Discount Applied ({booking.discountCode})</span>
                  <span>-{formatPrice(booking.discountAmount)}</span>
                </div>
              )}

              <div className="flex items-center justify-between text-slate-400">
                <span>Taxes & Airport Concession Fees</span>
                <span>+{formatPrice(booking.taxAmount)}</span>
              </div>

              <div className="flex items-center justify-between text-sm font-extrabold text-white pt-2 border-t border-white/10">
                <span>Total Paid / Reserved</span>
                <span className="text-amber-400 text-base">{formatPrice(booking.totalPrice)}</span>
              </div>
            </div>

            {/* Note */}
            <div className="text-[11px] text-slate-400 text-center leading-relaxed">
              Please present this digital or printed voucher along with your physical driver's license and credit card at the rental counter upon vehicle collection.
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
