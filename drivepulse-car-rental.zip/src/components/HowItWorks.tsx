import React from 'react';
import { useRental } from '../context/RentalContext';
import { Search, CalendarCheck, KeyRound, ArrowRight } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const { setActiveTab } = useRental();

  const steps = [
    {
      step: '01',
      icon: Search,
      title: 'Select Your Vehicle',
      description: 'Filter from our curated luxury, electric, SUV, and sports cars based on your style, seating, and budget.',
    },
    {
      step: '02',
      icon: CalendarCheck,
      title: 'Pick Dates & Add-ons',
      description: 'Choose your pickup/dropoff terminal, custom protection options, GPS navigation, or child seats with upfront pricing.',
    },
    {
      step: '03',
      icon: KeyRound,
      title: 'Instant Confirmation & Drive',
      description: 'Receive your instant digital voucher. Seamless zero-wait counter pickup or contactless mobile vehicle unlock.',
    },
  ];

  return (
    <section className="py-16 sm:py-20 relative border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2 block">
            Effortless Journey
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            How Renting With DrivePulse Works
          </h2>
          <p className="text-sm text-slate-300/80 mt-2">
            No long counter queues or confusing paperwork. We make car rental as easy as a 3-step digital checkout.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {steps.map((item) => (
            <div
              key={item.step}
              className="relative p-6 sm:p-8 rounded-3xl bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-amber-400/40 transition-all duration-300 flex flex-col justify-between group shadow-[0_8px_30px_rgba(0,0,0,0.25)] hover:-translate-y-1"
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform shadow-inner">
                    <item.icon className="w-7 h-7" />
                  </div>
                  <span className="text-3xl font-black text-white/20 group-hover:text-amber-400/40 transition-colors font-mono">
                    {item.step}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                <p className="text-xs sm:text-sm text-slate-300/80 leading-relaxed">{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={() => {
              setActiveTab('fleet');
              setTimeout(() => {
                document.getElementById('fleet-section')?.scrollIntoView({ behavior: 'smooth' });
              }, 50);
            }}
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-sm hover:brightness-110 transition-all shadow-lg shadow-amber-500/25 cursor-pointer border border-amber-300/30 active:scale-95"
          >
            <span>Start Your Reservation</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
