import React, { useState, useEffect } from 'react';
import { useRental } from '../context/RentalContext';
import { LOCATIONS, ADD_ONS } from '../data/carsData';
import { BookingAddOns } from '../types';
import confetti from 'canvas-confetti';
import { 
  X, 
  Calendar, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  User, 
  Mail, 
  Phone, 
  FileText, 
  Tag, 
  CheckCircle2, 
  Printer, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles,
  Car,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const BookingModal: React.FC = () => {
  const { 
    selectedCarForBooking, 
    setSelectedCarForBooking, 
    createBooking, 
    formatPrice, 
    quickSearchParams,
    setActiveTab,
    setViewingReceipt,
    showToast 
  } = useRental();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Step 1: Trip Details
  const [pickupLocation, setPickupLocation] = useState(quickSearchParams.pickupLocation || LOCATIONS[0].name);
  const [dropoffLocation, setDropoffLocation] = useState(quickSearchParams.dropoffLocation || LOCATIONS[0].name);
  const [pickupDate, setPickupDate] = useState(quickSearchParams.pickupDate);
  const [pickupTime, setPickupTime] = useState('10:00 AM');
  const [dropoffDate, setDropoffDate] = useState(quickSearchParams.dropoffDate);
  const [dropoffTime, setDropoffTime] = useState('10:00 AM');

  // Add-ons
  const [addOns, setAddOns] = useState<BookingAddOns>({
    insurance: true,
    gps: false,
    childSeat: false,
    additionalDriver: false,
    roadside: true,
  });

  // Step 2: Driver Details
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Step 3: Promo & Voucher
  const [promoInput, setPromoInput] = useState('DRIVE15');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; percent: number } | null>({
    code: 'DRIVE15',
    percent: 15,
  });

  // Resulting Booking on Step 4
  const [confirmedBooking, setConfirmedBooking] = useState<any>(null);

  // Calculate rental duration in days
  const calculateDays = () => {
    if (!pickupDate || !dropoffDate) return 1;
    const start = new Date(pickupDate).getTime();
    const end = new Date(dropoffDate).getTime();
    const diff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    return diff > 0 ? diff : 1;
  };

  const totalDays = calculateDays();

  // Price calculations
  const carPricePerDay = selectedCarForBooking?.pricePerDay || 0;
  const baseRentalCost = carPricePerDay * totalDays;

  // Addons cost
  let dailyAddOnsRate = 0;
  if (addOns.insurance) dailyAddOnsRate += 18;
  if (addOns.gps) dailyAddOnsRate += 8;
  if (addOns.childSeat) dailyAddOnsRate += 10;
  if (addOns.additionalDriver) dailyAddOnsRate += 12;
  if (addOns.roadside) dailyAddOnsRate += 6;

  const totalAddOnsCost = dailyAddOnsRate * totalDays;
  const subtotal = baseRentalCost + totalAddOnsCost;
  const discountAmount = appliedPromo ? Math.round(subtotal * (appliedPromo.percent / 100)) : 0;
  const taxableAmount = subtotal - discountAmount;
  const taxAmount = Math.round(taxableAmount * 0.08); // 8% sales tax
  const totalPrice = taxableAmount + taxAmount;

  if (!selectedCarForBooking) return null;

  const car = selectedCarForBooking;

  // Validation
  const validateStep2 = () => {
    const errors: Record<string, string> = {};
    if (!customerName.trim()) errors.customerName = 'Full name is required';
    if (!customerEmail.trim() || !customerEmail.includes('@')) {
      errors.customerEmail = 'Valid email is required';
    }
    if (!customerPhone.trim() || customerPhone.length < 7) {
      errors.customerPhone = 'Valid phone number is required';
    }
    if (!licenseNumber.trim()) {
      errors.licenseNumber = "Driver's license number is required";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleApplyPromo = () => {
    const code = promoInput.trim().toUpperCase();
    if (code === 'DRIVE15') {
      setAppliedPromo({ code: 'DRIVE15', percent: 15 });
      showToast('15% Promo discount applied!', 'success');
    } else if (code === 'SUMMER20') {
      setAppliedPromo({ code: 'SUMMER20', percent: 20 });
      showToast('20% Summer discount applied!', 'success');
    } else if (code === 'WELCOME10') {
      setAppliedPromo({ code: 'WELCOME10', percent: 10 });
      showToast('10% Welcome discount applied!', 'success');
    } else {
      showToast('Invalid promo code. Try "DRIVE15" or "SUMMER20"', 'error');
    }
  };

  const handleConfirmReservation = () => {
    const booking = createBooking({
      carId: car.id,
      carName: car.name,
      carBrand: car.brand,
      carImage: car.image,
      carPricePerDay: car.pricePerDay,
      customerName,
      customerEmail,
      customerPhone,
      licenseNumber,
      pickupLocation,
      dropoffLocation,
      pickupDate,
      pickupTime,
      dropoffDate,
      dropoffTime,
      totalDays,
      addOns,
      addOnsCost: totalAddOnsCost,
      subtotal,
      discountCode: appliedPromo?.code,
      discountAmount,
      taxAmount,
      totalPrice,
      specialRequests,
    });

    setConfirmedBooking(booking);
    setStep(4);

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#10b981', '#3b82f6'],
      });
    } catch (e) {
      // safe fallback
    }
  };

  const timeOptions = [
    '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM'
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            if (step !== 4) setSelectedCarForBooking(null);
          }}
          className="fixed inset-0 bg-slate-950/85 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-3xl bg-slate-900/60 backdrop-blur-2xl border border-white/15 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.6)] overflow-hidden z-10 my-auto max-h-[94vh] flex flex-col"
        >
          {/* Subtle top sheen */}
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />

          {/* Header Bar */}
          <div className="px-6 py-4 border-b border-white/10 bg-slate-950/60 backdrop-blur-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                <Car className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Car Rental Reservation</h3>
                <p className="text-xs text-slate-400">{car.name} ({car.year})</p>
              </div>
            </div>

            <button
              onClick={() => setSelectedCarForBooking(null)}
              className="p-2 rounded-full bg-white/[0.05] hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer border border-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper Indicator */}
          {step !== 4 && (
            <div className="px-6 py-3 bg-black/20 border-b border-white/10 flex items-center justify-between text-xs backdrop-blur-md">
              <div className={`flex items-center gap-2 ${step >= 1 ? 'text-amber-400 font-bold' : 'text-slate-500'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 1 ? 'bg-amber-500 text-slate-950 shadow-sm' : 'bg-white/10 text-slate-400'}`}>
                  1
                </span>
                <span>Trip Details & Add-ons</span>
              </div>
              <div className="h-0.5 w-8 bg-white/10" />
              <div className={`flex items-center gap-2 ${step >= 2 ? 'text-amber-400 font-bold' : 'text-slate-500'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 2 ? 'bg-amber-500 text-slate-950 shadow-sm' : 'bg-white/10 text-slate-400'}`}>
                  2
                </span>
                <span>Driver Contact</span>
              </div>
              <div className="h-0.5 w-8 bg-white/10" />
              <div className={`flex items-center gap-2 ${step >= 3 ? 'text-amber-400 font-bold' : 'text-slate-500'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 3 ? 'bg-amber-500 text-slate-950 shadow-sm' : 'bg-white/10 text-slate-400'}`}>
                  3
                </span>
                <span>Review & Confirm</span>
              </div>
            </div>
          )}

          {/* Body Content */}
          <div className="overflow-y-auto p-6 space-y-6 flex-1">
            {/* STEP 1: Dates, Locations & Add-ons */}
            {step === 1 && (
              <div className="space-y-6">
                {/* Vehicle Mini Bar */}
                <div className="flex items-center gap-4 p-3.5 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10">
                  <img src={car.image} alt={car.name} referrerPolicy="no-referrer" className="w-20 h-14 object-cover rounded-xl shrink-0 border border-white/10" />
                  <div className="flex-1">
                    <div className="text-xs text-slate-400">{car.brand} • {car.category}</div>
                    <div className="text-sm font-bold text-white">{car.name}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-base font-black text-amber-400">{formatPrice(car.pricePerDay)}</div>
                    <div className="text-[11px] text-slate-400">per day</div>
                  </div>
                </div>

                {/* Locations */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-amber-400" /> Pick-up Location
                    </label>
                    <select
                      id="booking-pickup-location"
                      value={pickupLocation}
                      onChange={(e) => setPickupLocation(e.target.value)}
                      className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3 py-2.5 text-sm text-slate-200 focus:border-amber-400/60 focus:outline-none cursor-pointer"
                    >
                      {LOCATIONS.map((loc) => (
                        <option key={loc.id} value={loc.name} className="bg-slate-900">
                          {loc.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400" /> Return Location
                    </label>
                    <select
                      id="booking-dropoff-location"
                      value={dropoffLocation}
                      onChange={(e) => setDropoffLocation(e.target.value)}
                      className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3 py-2.5 text-sm text-slate-200 focus:border-amber-400/60 focus:outline-none cursor-pointer"
                    >
                      {LOCATIONS.map((loc) => (
                        <option key={loc.id} value={loc.name} className="bg-slate-900">
                          {loc.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Dates & Times */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-black/40 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-amber-400" /> Pick-up Date & Time
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="date"
                        id="booking-pickup-date"
                        min={new Date().toISOString().split('T')[0]}
                        value={pickupDate}
                        onChange={(e) => setPickupDate(e.target.value)}
                        className="w-full bg-transparent text-xs text-white focus:outline-none [color-scheme:dark]"
                      />
                      <select
                        value={pickupTime}
                        onChange={(e) => setPickupTime(e.target.value)}
                        className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-200"
                      >
                        {timeOptions.map((t) => (
                          <option key={t} value={t} className="bg-slate-900">{t}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="bg-black/40 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-amber-400" /> Return Date & Time
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="date"
                        id="booking-dropoff-date"
                        min={pickupDate || new Date().toISOString().split('T')[0]}
                        value={dropoffDate}
                        onChange={(e) => setDropoffDate(e.target.value)}
                        className="w-full bg-transparent text-xs text-white focus:outline-none [color-scheme:dark]"
                      />
                      <select
                        value={dropoffTime}
                        onChange={(e) => setDropoffTime(e.target.value)}
                        className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-200"
                      >
                        {timeOptions.map((t) => (
                          <option key={t} value={t} className="bg-slate-900">{t}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Rental Duration Summary */}
                <div className="px-4 py-2.5 rounded-xl bg-amber-500/10 backdrop-blur-md border border-amber-500/20 flex items-center justify-between text-xs">
                  <span className="text-amber-300 font-semibold">Total Duration:</span>
                  <span className="text-white font-bold">{totalDays} Rental {totalDays === 1 ? 'Day' : 'Days'}</span>
                </div>

                {/* Add-on Protection & Extras */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Optional Add-ons & Protection</h4>
                  <div className="space-y-2.5">
                    {ADD_ONS.map((addon) => {
                      const isChecked = addOns[addon.id as keyof BookingAddOns];
                      return (
                        <label
                          key={addon.id}
                          className={`flex items-start justify-between p-3.5 rounded-2xl border transition-all cursor-pointer backdrop-blur-md ${
                            isChecked
                              ? 'bg-amber-500/10 border-amber-500/40 text-white'
                              : 'bg-black/30 border-white/10 text-slate-300 hover:border-white/20'
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <input
                              type="checkbox"
                              id={`addon-check-${addon.id}`}
                              checked={isChecked}
                              onChange={(e) =>
                                setAddOns((prev) => ({ ...prev, [addon.id]: e.target.checked }))
                              }
                              className="mt-1 w-4 h-4 rounded text-amber-500 focus:ring-amber-500 bg-slate-900 border-white/20 cursor-pointer"
                            />
                            <div>
                              <div className="text-xs font-bold flex items-center gap-1.5">
                                <span>{addon.name}</span>
                                {addon.recommended && (
                                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 font-bold">
                                    Recommended
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-400 mt-0.5">{addon.description}</p>
                            </div>
                          </div>

                          <div className="text-right shrink-0 ml-3">
                            <div className="text-xs font-bold text-amber-400">+{formatPrice(addon.pricePerDay)}</div>
                            <div className="text-[10px] text-slate-400">/day</div>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2: Driver Details */}
            {step === 2 && (
              <div className="space-y-4">
                <div className="p-3.5 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 text-xs text-slate-300 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Primary driver must be at least 21 years of age and hold a valid physical driver license.</span>
                </div>

                {/* Full Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-amber-400" /> Full Legal Name *
                  </label>
                  <input
                    type="text"
                    id="driver-name-input"
                    placeholder="e.g. Alexander Mitchell"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-amber-400/60 focus:bg-black/60 focus:outline-none"
                  />
                  {formErrors.customerName && (
                    <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {formErrors.customerName}
                    </p>
                  )}
                </div>

                {/* Email & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-amber-400" /> Email Address *
                    </label>
                    <input
                      type="email"
                      id="driver-email-input"
                      placeholder="alexander@example.com"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-amber-400/60 focus:bg-black/60 focus:outline-none"
                    />
                    {formErrors.customerEmail && (
                      <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {formErrors.customerEmail}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-amber-400" /> Contact Phone Number *
                    </label>
                    <input
                      type="tel"
                      id="driver-phone-input"
                      placeholder="+1 (555) 019-2834"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-amber-400/60 focus:bg-black/60 focus:outline-none"
                    />
                    {formErrors.customerPhone && (
                      <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {formErrors.customerPhone}
                      </p>
                    )}
                  </div>
                </div>

                {/* License Number */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-amber-400" /> Driver's License Number *
                  </label>
                  <input
                    type="text"
                    id="driver-license-input"
                    placeholder="e.g. DL-83921-CA"
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-amber-400/60 focus:bg-black/60 focus:outline-none uppercase"
                  />
                  {formErrors.licenseNumber && (
                    <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {formErrors.licenseNumber}
                    </p>
                  )}
                </div>

                {/* Special Instructions */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Special Requests or Flight Number (Optional)
                  </label>
                  <textarea
                    rows={2}
                    id="driver-notes-input"
                    placeholder="e.g. Arriving on Flight AA104, please prepare vehicle for child seat installation."
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    className="w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-xl p-3 text-xs text-white focus:border-amber-400/60 focus:bg-black/60 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* STEP 3: Review, Price Breakdown & Voucher */}
            {step === 3 && (
              <div className="space-y-5">
                {/* Trip Summary Card */}
                <div className="p-4 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 space-y-3">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div>
                      <div className="text-xs text-slate-400">Selected Vehicle</div>
                      <div className="text-sm font-bold text-white">{car.name}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-slate-400">Renter</div>
                      <div className="text-sm font-bold text-white">{customerName}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block">Pick-up</span>
                      <span className="font-semibold text-slate-200">{pickupLocation}</span>
                      <span className="text-amber-400 block mt-0.5">{pickupDate} at {pickupTime}</span>
                    </div>

                    <div>
                      <span className="text-slate-400 block">Return</span>
                      <span className="font-semibold text-slate-200">{dropoffLocation}</span>
                      <span className="text-amber-400 block mt-0.5">{dropoffDate} at {dropoffTime}</span>
                    </div>
                  </div>
                </div>

                {/* Voucher Promo Code Bar */}
                <div className="p-3.5 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10">
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-amber-400" /> Have a Promo Code?
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      id="promo-code-input"
                      placeholder="Try DRIVE15 or SUMMER20"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none uppercase font-mono"
                    />
                    <button
                      type="button"
                      id="apply-promo-btn"
                      onClick={handleApplyPromo}
                      className="px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30 text-xs font-bold transition-colors cursor-pointer"
                    >
                      Apply
                    </button>
                  </div>
                  {appliedPromo && (
                    <div className="text-[11px] text-emerald-400 mt-1.5 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Applied: <strong>{appliedPromo.code}</strong> ({appliedPromo.percent}% discount)
                    </div>
                  )}
                </div>

                {/* Detailed Transparent Price Breakdown */}
                <div className="p-4 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 space-y-2 text-xs">
                  <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2">Price Breakdown</h4>

                  <div className="flex items-center justify-between text-slate-300">
                    <span>Base Vehicle Rental ({totalDays} days × {formatPrice(car.pricePerDay)})</span>
                    <span>{formatPrice(baseRentalCost)}</span>
                  </div>

                  {totalAddOnsCost > 0 && (
                    <div className="flex items-center justify-between text-slate-300">
                      <span>Add-on Protections & Extras ({totalDays} days)</span>
                      <span>+{formatPrice(totalAddOnsCost)}</span>
                    </div>
                  )}

                  {discountAmount > 0 && (
                    <div className="flex items-center justify-between text-emerald-400 font-semibold">
                      <span>Promo Discount ({appliedPromo?.code})</span>
                      <span>-{formatPrice(discountAmount)}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-slate-400 pt-1">
                    <span>Estimated Taxes & State Fees (8%)</span>
                    <span>+{formatPrice(taxAmount)}</span>
                  </div>

                  <div className="flex items-center justify-between text-base font-extrabold text-white pt-2 border-t border-white/10">
                    <span>Total Amount Due</span>
                    <span className="text-amber-400 text-lg">{formatPrice(totalPrice)}</span>
                  </div>

                  <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between">
                    <span>Refundable Security Deposit (Hold upon pickup)</span>
                    <span className="text-slate-300 font-semibold">{formatPrice(car.depositAmount)}</span>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 4: Success & Confirmation Voucher */}
            {step === 4 && confirmedBooking && (
              <div className="text-center space-y-6 py-4">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10">
                  <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
                </div>

                <div>
                  <h3 className="text-2xl font-extrabold text-white mb-1">Reservation Confirmed!</h3>
                  <p className="text-xs text-slate-300 max-w-md mx-auto">
                    Your reservation has been locked into the dispatch calendar. A confirmation receipt has been sent to <strong>{confirmedBooking.customerEmail}</strong>.
                  </p>
                </div>

                {/* Digital Voucher Card */}
                <div id="printable-voucher" className="p-5 rounded-2xl bg-black/40 backdrop-blur-md border border-white/15 text-left space-y-4 shadow-xl">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Booking Number</span>
                      <div className="text-lg font-black text-amber-400 font-mono">{confirmedBooking.bookingNumber}</div>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                      Confirmed & Active
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-slate-400 block">Vehicle</span>
                      <span className="font-bold text-white">{confirmedBooking.carName}</span>
                    </div>

                    <div>
                      <span className="text-slate-400 block">Primary Driver</span>
                      <span className="font-bold text-white">{confirmedBooking.customerName}</span>
                    </div>

                    <div>
                      <span className="text-slate-400 block">Pick-up Point</span>
                      <span className="font-semibold text-slate-200">{confirmedBooking.pickupLocation}</span>
                      <span className="text-amber-400 block">{confirmedBooking.pickupDate} ({confirmedBooking.pickupTime})</span>
                    </div>

                    <div>
                      <span className="text-slate-400 block">Return Point</span>
                      <span className="font-semibold text-slate-200">{confirmedBooking.dropoffLocation}</span>
                      <span className="text-amber-400 block">{confirmedBooking.dropoffDate} ({confirmedBooking.dropoffTime})</span>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                    <span className="text-slate-400">Total Charged</span>
                    <span className="text-base font-extrabold text-white">{formatPrice(confirmedBooking.totalPrice)}</span>
                  </div>
                </div>

                {/* Success Actions */}
                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      setSelectedCarForBooking(null);
                      setViewingReceipt(confirmedBooking);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/10 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-white/10 cursor-pointer backdrop-blur-md"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print / View Invoice</span>
                  </button>

                  <button
                    onClick={() => {
                      setSelectedCarForBooking(null);
                      setActiveTab('bookings');
                    }}
                    className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer"
                  >
                    <span>View in My Bookings</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Stepper Bottom Controls */}
          {step !== 4 && (
            <div className="p-4 sm:p-6 border-t border-white/10 bg-slate-950/60 backdrop-blur-xl flex items-center justify-between">
              {step > 1 ? (
                <button
                  type="button"
                  id="booking-step-back-btn"
                  onClick={() => setStep((prev) => (prev - 1) as any)}
                  className="px-4 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-300 flex items-center gap-1.5 cursor-pointer backdrop-blur-md"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setSelectedCarForBooking(null)}
                  className="px-4 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-400 cursor-pointer backdrop-blur-md"
                >
                  Cancel
                </button>
              )}

              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">Current Total</span>
                <span className="text-lg font-black text-amber-400">{formatPrice(totalPrice)}</span>
              </div>

              {step === 1 && (
                <button
                  type="button"
                  id="booking-step1-next-btn"
                  onClick={() => {
                    const start = new Date(pickupDate);
                    const end = new Date(dropoffDate);
                    if (end <= start) {
                      showToast('Return date must be after pick-up date', 'error');
                      return;
                    }
                    setStep(2);
                  }}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 hover:brightness-110 cursor-pointer border border-amber-300/30"
                >
                  <span>Continue to Driver Info</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}

              {step === 2 && (
                <button
                  type="button"
                  id="booking-step2-next-btn"
                  onClick={() => {
                    if (validateStep2()) {
                      setStep(3);
                    }
                  }}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 hover:brightness-110 cursor-pointer border border-amber-300/30"
                >
                  <span>Review & Summary</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}

              {step === 3 && (
                <button
                  type="button"
                  id="booking-step3-confirm-btn"
                  onClick={handleConfirmReservation}
                  className="px-7 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/25 hover:brightness-110 active:scale-95 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Confirm Reservation</span>
                </button>
              )}
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
