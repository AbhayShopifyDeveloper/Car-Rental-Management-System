import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { CarCard } from './CarCard';
import { Sparkles, ArrowRight } from 'lucide-react';

export const FeaturedCars: React.FC = () => {
  const { cars, setActiveTab, setFilters } = useRental();
  const [selectedTag, setSelectedTag] = useState<'all' | 'Electric' | 'Sports' | 'Luxury'>('all');

  const featuredCars = cars.filter((c) => c.featured);
  const displayCars = selectedTag === 'all' 
    ? featuredCars 
    : featuredCars.filter((c) => c.category === selectedTag);

  return (
    <section className="py-12 sm:py-16 bg-transparent border-t border-white/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-4 h-4" />
              <span>Handpicked Highlights</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
              Featured Top-Tier Vehicles
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Top customer favorites known for supreme comfort, exhilarating power, and refined road presence.
            </p>
          </div>

          {/* Quick Filter Tabs */}
          <div className="flex items-center gap-2 bg-white/[0.04] backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 self-start md:self-auto shadow-inner">
            {(['all', 'Electric', 'Sports', 'Luxury'] as const).map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all cursor-pointer ${
                  selectedTag === tag
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                {tag === 'all' ? 'All Featured' : tag}
              </button>
            ))}
          </div>
        </div>

        {/* Cars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {displayCars.slice(0, 3).map((car) => (
            <CarCard key={car.id} car={car} viewMode="grid" />
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <button
            onClick={() => {
              setActiveTab('fleet');
              setTimeout(() => {
                document.getElementById('fleet-section')?.scrollIntoView({ behavior: 'smooth' });
              }, 50);
            }}
            className="inline-flex items-center gap-2 px-8 py-3 rounded-2xl bg-white/[0.05] hover:bg-white/10 backdrop-blur-xl border border-white/15 text-amber-300 font-bold text-xs sm:text-sm transition-all shadow-lg hover:border-amber-400/40 cursor-pointer"
          >
            <span>View Full Fleet of {cars.length} Vehicles</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
