import React, { useState } from 'react';
import { useRental } from '../context/RentalContext';
import { 
  Car, 
  PhoneCall, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  ArrowRight,
  Send,
  CheckCircle2,
  Globe
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { setActiveTab, showToast } = useRental();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim() && newsletterEmail.includes('@')) {
      setSubscribed(true);
      showToast('Thank you for subscribing! You will receive VIP discounts.', 'success');
      setNewsletterEmail('');
    } else {
      showToast('Please enter a valid email address', 'error');
    }
  };

  return (
    <footer className="bg-slate-950 border-t border-slate-800/80 text-slate-400 text-xs">
      {/* Top Banner / Newsletter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-b border-slate-900">
        <div className="p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-amber-950/20 border border-slate-800 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="max-w-xl text-center lg:text-left">
            <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] block mb-1">
              Join the DrivePulse Club
            </span>
            <h3 className="text-2xl font-extrabold text-white">
              Unlock Exclusive Roadtrip Perks & Flash Discounts
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Get member-only weekend rates, free upgrade vouchers, and early access to new supercars.
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="w-full lg:w-auto flex flex-col sm:flex-row items-center gap-2">
            <input
              type="email"
              placeholder="Enter your email"
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              className="w-full sm:w-72 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
            />
            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer shrink-0"
            >
              <span>Subscribe</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
        {/* Brand column */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-slate-950 font-bold">
              <Car className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="text-lg font-extrabold text-white tracking-tight font-serif">DrivePulse</span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
            Premium car rental and modern fleet management. Delivering seamless keyless pick-ups, transparent pricing, and 24/7 road assistance across prime metropolitan terminals.
          </p>

          <div className="space-y-1.5 pt-2 text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
              <span>24/7 Hotline: +1 (800) 555-DRIVE</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Mail className="w-3.5 h-3.5 text-amber-400" />
              <span>reservations@drivepulse.com</span>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-3">Navigation</h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => { setActiveTab('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">
                Home
              </button>
            </li>
            <li>
              <button onClick={() => { setActiveTab('fleet'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">
                Vehicle Fleet
              </button>
            </li>
            <li>
              <button onClick={() => { setActiveTab('bookings'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">
                My Bookings
              </button>
            </li>
            <li>
              <button onClick={() => { setActiveTab('about'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">
                How It Works
              </button>
            </li>
            <li>
              <button onClick={() => { setActiveTab('admin'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">
                Admin Fleet Hub
              </button>
            </li>
          </ul>
        </div>

        {/* Popular Categories */}
        <div>
          <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-3">Vehicle Classes</h4>
          <ul className="space-y-2">
            <li><span className="hover:text-white cursor-pointer">Luxury Sedans</span></li>
            <li><span className="hover:text-white cursor-pointer">Electric Vehicles (EV)</span></li>
            <li><span className="hover:text-white cursor-pointer">All-Terrain SUVs</span></li>
            <li><span className="hover:text-white cursor-pointer">Sports & Performance</span></li>
            <li><span className="hover:text-white cursor-pointer">Executive Passenger Vans</span></li>
          </ul>
        </div>

        {/* Major Hubs */}
        <div>
          <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-3">Popular Hubs</h4>
          <ul className="space-y-2">
            <li><span>Los Angeles (LAX)</span></li>
            <li><span>San Francisco (SFO)</span></li>
            <li><span>Las Vegas Grand Station</span></li>
            <li><span>Miami International (MIA)</span></li>
            <li><span>Denver Airport (DEN)</span></li>
          </ul>
        </div>
      </div>

      {/* Bottom Legal Bar */}
      <div className="border-t border-slate-900 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} DrivePulse Car Rental Management Systems. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-slate-400 cursor-pointer">Terms of Rental</span>
            <span className="hover:text-slate-400 cursor-pointer">Insurance Coverage</span>
            <span className="hover:text-slate-400 cursor-pointer">Cookie Settings</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
