import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Car,
  Booking,
  FilterState,
  CurrencyCode,
  BookingStatus,
} from '../types';
import { INITIAL_CARS, CURRENCIES, LOCATIONS } from '../data/carsData';

interface Toast {
  id: string;
  type: 'success' | 'info' | 'error';
  message: string;
}

interface RentalContextType {
  // Navigation & view
  activeTab: 'home' | 'fleet' | 'bookings' | 'admin' | 'about';
  setActiveTab: (tab: 'home' | 'fleet' | 'bookings' | 'admin' | 'about') => void;

  // Cars Fleet
  cars: Car[];
  addCar: (car: Omit<Car, 'id' | 'rating' | 'reviewsCount'>) => void;
  updateCar: (id: string, updated: Partial<Car>) => void;
  deleteCar: (id: string) => void;
  resetDefaultFleet: () => void;

  // Bookings
  bookings: Booking[];
  createBooking: (bookingData: Omit<Booking, 'id' | 'bookingNumber' | 'createdAt' | 'status'>) => Booking;
  cancelBooking: (id: string) => void;
  updateBookingStatus: (id: string, status: BookingStatus) => void;

  // Favorites
  favorites: string[];
  toggleFavorite: (carId: string) => void;
  isFavorite: (carId: string) => boolean;

  // Filters
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  filteredCars: Car[];

  // Modals
  selectedCarForDetails: Car | null;
  setSelectedCarForDetails: (car: Car | null) => void;
  selectedCarForBooking: Car | null;
  setSelectedCarForBooking: (car: Car | null) => void;
  viewingReceipt: Booking | null;
  setViewingReceipt: (booking: Booking | null) => void;

  // Quick Search pre-population
  quickSearchParams: {
    pickupLocation: string;
    dropoffLocation: string;
    pickupDate: string;
    dropoffDate: string;
    category: string;
  };
  setQuickSearchParams: React.Dispatch<React.SetStateAction<{
    pickupLocation: string;
    dropoffLocation: string;
    pickupDate: string;
    dropoffDate: string;
    category: string;
  }>>;

  // Currency
  currency: CurrencyCode;
  setCurrency: (code: CurrencyCode) => void;
  formatPrice: (usdAmount: number) => string;

  // Notification Toasts
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'info' | 'error') => void;
  removeToast: (id: string) => void;
}

const defaultFilters: FilterState = {
  search: '',
  category: 'All',
  fuelType: 'All',
  transmission: 'All',
  minPrice: 0,
  maxPrice: 300,
  seats: 'All',
  onlyAvailable: false,
  sortBy: 'featured',
};

const RentalContext = createContext<RentalContextType | undefined>(undefined);

export const RentalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'home' | 'fleet' | 'bookings' | 'admin' | 'about'>('home');

  // Load cars from localStorage or defaults
  const [cars, setCars] = useState<Car[]>(() => {
    const saved = localStorage.getItem('drivepulse_cars');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse cars from storage', e);
      }
    }
    return INITIAL_CARS;
  });

  // Save cars to localStorage
  useEffect(() => {
    localStorage.setItem('drivepulse_cars', JSON.stringify(cars));
  }, [cars]);

  // Load bookings from localStorage
  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('drivepulse_bookings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse bookings from storage', e);
      }
    }
    return [
      {
        id: 'book-demo-1',
        bookingNumber: 'DP-89241',
        carId: 'car-1',
        carName: 'Tesla Model Y Performance',
        carBrand: 'Tesla',
        carImage: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=1200&q=80',
        carPricePerDay: 89,
        customerName: 'Alex Johnson',
        customerEmail: 'alex.johnson@example.com',
        customerPhone: '+1 (555) 321-9876',
        licenseNumber: 'DL-98432-CA',
        pickupLocation: 'Los Angeles Int. Airport (LAX)',
        dropoffLocation: 'Los Angeles Int. Airport (LAX)',
        pickupDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
        pickupTime: '10:00 AM',
        dropoffDate: new Date(Date.now() + 86400000 * 6).toISOString().split('T')[0],
        dropoffTime: '10:00 AM',
        totalDays: 4,
        addOns: {
          insurance: true,
          gps: false,
          childSeat: false,
          additionalDriver: true,
          roadside: true,
        },
        addOnsCost: 144, // ($18 + $12 + $6) * 4 days
        subtotal: 500,
        discountCode: 'WELCOME10',
        discountAmount: 50,
        taxAmount: 36,
        totalPrice: 486,
        status: 'Confirmed',
        specialRequests: 'Please ensure battery is at 90% or above.',
        createdAt: new Date().toISOString(),
      },
    ];
  });

  useEffect(() => {
    localStorage.setItem('drivepulse_bookings', JSON.stringify(bookings));
  }, [bookings]);

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('drivepulse_favorites');
    return saved ? JSON.parse(saved) : ['car-1', 'car-2'];
  });

  useEffect(() => {
    localStorage.setItem('drivepulse_favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (carId: string) => {
    setFavorites((prev) => {
      const exists = prev.includes(carId);
      const next = exists ? prev.filter((id) => id !== carId) : [...prev, carId];
      showToast(exists ? 'Removed from saved vehicles' : 'Added to saved vehicles', 'info');
      return next;
    });
  };

  const isFavorite = (carId: string) => favorites.includes(carId);

  // Filters
  const [filters, setFilters] = useState<FilterState>(defaultFilters);

  const resetFilters = () => {
    setFilters(defaultFilters);
  };

  // Quick Search state
  const [quickSearchParams, setQuickSearchParams] = useState({
    pickupLocation: LOCATIONS[0].name,
    dropoffLocation: LOCATIONS[0].name,
    pickupDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    dropoffDate: new Date(Date.now() + 86400000 * 4).toISOString().split('T')[0],
    category: 'All',
  });

  // Modals
  const [selectedCarForDetails, setSelectedCarForDetails] = useState<Car | null>(null);
  const [selectedCarForBooking, setSelectedCarForBooking] = useState<Car | null>(null);
  const [viewingReceipt, setViewingReceipt] = useState<Booking | null>(null);

  // Currency
  const [currency, setCurrency] = useState<CurrencyCode>('USD');

  const formatPrice = (usdAmount: number): string => {
    const config = CURRENCIES[currency] || CURRENCIES.USD;
    const converted = usdAmount * config.rate;
    if (currency === 'INR') {
      return `${config.symbol}${Math.round(converted).toLocaleString('en-IN')}`;
    }
    return `${config.symbol}${Math.round(converted).toLocaleString()}`;
  };

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Fleet management actions
  const addCar = (newCarData: Omit<Car, 'id' | 'rating' | 'reviewsCount'>) => {
    const newCar: Car = {
      ...newCarData,
      id: `car-${Date.now()}`,
      rating: 5.0,
      reviewsCount: 1,
      isAvailable: newCarData.status === 'Available',
    };
    setCars((prev) => [newCar, ...prev]);
    showToast(`Vehicle ${newCar.name} added to fleet!`, 'success');
  };

  const updateCar = (id: string, updated: Partial<Car>) => {
    setCars((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const next = { ...c, ...updated };
          if (updated.status !== undefined) {
            next.isAvailable = updated.status === 'Available';
          }
          return next;
        }
        return c;
      })
    );
    showToast('Vehicle updated successfully', 'success');
  };

  const deleteCar = (id: string) => {
    const target = cars.find((c) => c.id === id);
    setCars((prev) => prev.filter((c) => c.id !== id));
    showToast(`Removed ${target ? target.name : 'car'} from fleet`, 'info');
  };

  const resetDefaultFleet = () => {
    setCars(INITIAL_CARS);
    localStorage.removeItem('drivepulse_cars');
    showToast('Fleet restored to standard catalog', 'info');
  };

  // Booking actions
  const createBooking = (bookingData: Omit<Booking, 'id' | 'bookingNumber' | 'createdAt' | 'status'>): Booking => {
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const newBooking: Booking = {
      ...bookingData,
      id: `book-${Date.now()}`,
      bookingNumber: `DP-${randomNum}`,
      status: 'Confirmed',
      createdAt: new Date().toISOString(),
    };

    setBookings((prev) => [newBooking, ...prev]);

    // Optional: mark car as reserved
    updateCar(bookingData.carId, { status: 'Reserved' });

    showToast(`Booking ${newBooking.bookingNumber} confirmed!`, 'success');
    return newBooking;
  };

  const cancelBooking = (id: string) => {
    const booking = bookings.find((b) => b.id === id);
    if (!booking) return;

    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: 'Cancelled' } : b))
    );

    // Free up car
    updateCar(booking.carId, { status: 'Available' });
    showToast(`Reservation #${booking.bookingNumber} cancelled`, 'info');
  };

  const updateBookingStatus = (id: string, status: BookingStatus) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status } : b))
    );
    showToast(`Booking updated to ${status}`, 'success');
  };

  // Computed filtered & sorted cars
  const filteredCars = React.useMemo(() => {
    return cars.filter((car) => {
      // Search term
      if (filters.search.trim()) {
        const query = filters.search.toLowerCase();
        const matchesQuery =
          car.name.toLowerCase().includes(query) ||
          car.brand.toLowerCase().includes(query) ||
          car.model.toLowerCase().includes(query) ||
          car.location.toLowerCase().includes(query) ||
          car.features.some((f) => f.toLowerCase().includes(query));
        if (!matchesQuery) return false;
      }

      // Category
      if (filters.category !== 'All' && car.category !== filters.category) {
        return false;
      }

      // Fuel Type
      if (filters.fuelType !== 'All' && car.fuelType !== filters.fuelType) {
        return false;
      }

      // Transmission
      if (filters.transmission !== 'All' && car.transmission !== filters.transmission) {
        return false;
      }

      // Price range
      if (car.pricePerDay < filters.minPrice || car.pricePerDay > filters.maxPrice) {
        return false;
      }

      // Seats
      if (filters.seats !== 'All') {
        if (filters.seats === 7) {
          if (car.seats < 7) return false;
        } else if (car.seats !== filters.seats) {
          return false;
        }
      }

      // Availability
      if (filters.onlyAvailable && !car.isAvailable) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'price-asc') return a.pricePerDay - b.pricePerDay;
      if (filters.sortBy === 'price-desc') return b.pricePerDay - a.pricePerDay;
      if (filters.sortBy === 'rating-desc') return b.rating - a.rating || b.reviewsCount - a.reviewsCount;
      if (filters.sortBy === 'name-asc') return a.name.localeCompare(b.name);
      // 'featured'
      if (a.featured && !b.featured) return -1;
      if (!a.featured && b.featured) return 1;
      return b.rating - a.rating;
    });
  }, [cars, filters]);

  return (
    <RentalContext.Provider
      value={{
        activeTab,
        setActiveTab,
        cars,
        addCar,
        updateCar,
        deleteCar,
        resetDefaultFleet,
        bookings,
        createBooking,
        cancelBooking,
        updateBookingStatus,
        favorites,
        toggleFavorite,
        isFavorite,
        filters,
        setFilters,
        resetFilters,
        filteredCars,
        selectedCarForDetails,
        setSelectedCarForDetails,
        selectedCarForBooking,
        setSelectedCarForBooking,
        viewingReceipt,
        setViewingReceipt,
        quickSearchParams,
        setQuickSearchParams,
        currency,
        setCurrency,
        formatPrice,
        toasts,
        showToast,
        removeToast,
      }}
    >
      {children}
    </RentalContext.Provider>
  );
};

export const useRental = () => {
  const context = useContext(RentalContext);
  if (!context) {
    throw new Error('useRental must be used within a RentalProvider');
  }
  return context;
};
